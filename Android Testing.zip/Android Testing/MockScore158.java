
public class MockScore158 extends Score {

//	// Define the 158 scoring game (handles standard in frame 9, strike in frame 10)
//	int [] individualThrows158 = {0, 10, 10, 0, 10, 0, 10, 0, 1, 4, 5, 5, 10, 0, 2, 7, 3, 0, 10, 2, 4};
//	int [] cumulativeFrameScores158 = {20, 50, 71, 86, 91, 111, 130, 139, 142, 158};
	
	public MockScore158(){
		individualThrows[0] = 0;
		individualThrows[1] = 10;
		individualThrows[2] = 10;
		individualThrows[3] = 0;
		individualThrows[4] = 10;
		individualThrows[5] = 0;
		individualThrows[6] = 10;
		individualThrows[7] = 0;
		individualThrows[8] = 1;
		individualThrows[9] = 4;
		individualThrows[10] = 5;
		individualThrows[11] = 5;
		individualThrows[12] = 10;
		individualThrows[13] = 0;
		individualThrows[14] = 2;
		individualThrows[15] = 7;
		individualThrows[16] = 3;
		individualThrows[17] = 0;
		individualThrows[18] = 10;
		individualThrows[19] = 2;
		individualThrows[20] = 4;
		
		cumulativeFrameScores[0] = 20;
		cumulativeFrameScores[1] = 50;
		cumulativeFrameScores[2] = 71;
		cumulativeFrameScores[3] = 86;
		cumulativeFrameScores[4] = 91;
		cumulativeFrameScores[5] = 111;
		cumulativeFrameScores[6] = 130;
		cumulativeFrameScores[7] = 139;
		cumulativeFrameScores[8] = 142;
		cumulativeFrameScores[9] = 158;
	}
}
