
public class MockScore125 extends Score {
//	// Define the 125 scoring game (handles spare in frame 9, double strike in frame 10)
//	int [] individualThrows125 = {2, 5, 10, 0, 5, 1, 0, 0, 3, 0, 5, 5, 10, 0, 7, 3, 3, 7, 10, 10, 0};
//	int [] cumulativeFrameScores125 = {7, 23, 29, 29, 32, 52, 72, 85, 105, 125};
	
	public MockScore125(){
		individualThrows[0] = 2;
		individualThrows[1] = 5;
		individualThrows[2] = 10;
		individualThrows[3] = 0;
		individualThrows[4] = 5;
		individualThrows[5] = 1;
		individualThrows[6] = 0;
		individualThrows[7] = 0;
		individualThrows[8] = 3;
		individualThrows[9] = 0;
		individualThrows[10] = 5;
		individualThrows[11] = 5;
		individualThrows[12] = 10;
		individualThrows[13] = 0;
		individualThrows[14] = 7;
		individualThrows[15] = 3;
		individualThrows[16] = 3;
		individualThrows[17] = 7;
		individualThrows[18] = 10;
		individualThrows[19] = 10;
		individualThrows[20] = 0;

		cumulativeFrameScores[0] = 7;
		cumulativeFrameScores[1] = 23;
		cumulativeFrameScores[2] = 29;
		cumulativeFrameScores[3] = 29;
		cumulativeFrameScores[4] = 32;
		cumulativeFrameScores[5] = 52;
		cumulativeFrameScores[6] = 72;
		cumulativeFrameScores[7] = 85;
		cumulativeFrameScores[8] = 105;
		cumulativeFrameScores[9] = 125;
	}
	
}
