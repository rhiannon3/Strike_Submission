import static org.junit.Assert.*;

import org.junit.Test;

public class TestScoreAlgorithm {
	String username;

	@Test
	public void test() {
		username = "mock_username";
		testSignUp();
		testLogin();
		testSaveGame();
		testLoadGame();
	
	}

	public void testSignUp(){
		SignUpDAO signUpDAO = new SignUpDAO(username, "password", "password");
		if (!signUpDAO.result.equals("Sign up successful")){
			fail()
		}
	}
		
	public void testLogin(){
		LoginDAO loginDAO = new LoginDAO(username, "password");
		if (!loginDAO.result.equals("Login successful")){
			fail();
		}
	}

	public void testSaveGame(){
		SaveGameDAO saveGameDAO = new SaveGameDAO(username, "mock_game_data");
		if (!saveGameDAO.result.equals("Game Saved")){
			fail();
		}
	}
	
	public voif testLoadGame(){
		LoadGameDAO loadGameDAO = new LoadGameDAO(username);
		if (!loadGameDAO.result.equals("mock_game_data")){
			fail();
		}
	}

}
