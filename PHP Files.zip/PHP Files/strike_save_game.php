<?php 
require "strike_connection.php";
$user_name = $_POST["user_name"];
$game_data = $_POST["game_data"];
$mysql_qry = "UPDATE `user_account_data` SET `game_data` = ('$game_data') WHERE `username` like '$user_name';";
if ($connection->query($mysql_qry) === true){
echo "Game Saved";
} 
else { 
echo "Error: " . $mysql_qry . "<br>" . $connection->error;
}
?>

