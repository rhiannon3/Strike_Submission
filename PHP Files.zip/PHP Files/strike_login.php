<?php 
require "strike_connection.php";
$user_name = $_POST["user_name"];
$user_password = $_POST["user_password"];
$mysql_qry = "select * from user_account_data where username like '$user_name' and password like '$user_password';";
$result = mysqli_query($connection , $mysql_qry);
if(mysqli_num_rows($result) > 0) {
echo "Login successful";
}
else {
echo "Login not successful";
}
 
?>