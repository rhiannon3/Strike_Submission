<?php 
require "strike_connection.php";
$user_name = $_POST["user_name"];
$user_password = $_POST["user_password"];
$mysql_qry = "select * from user_account_data where username like '$user_name';";
$result = mysqli_query($connection ,$mysql_qry);
if(mysqli_num_rows($result) > 0) {
echo "Username is already taken";
}
else {
$mysql_qry2 = "INSERT INTO `user_account_data` (`username`, `password`, `game_data`) VALUES ('$user_name', '$user_password', 'N/A');";
$result2 = mysqli_query($connection ,$mysql_qry2);
echo "Sign up successful";
}
 
?>