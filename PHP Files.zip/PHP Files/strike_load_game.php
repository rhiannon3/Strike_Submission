<?php 
require "strike_connection.php";
$user_name = $_POST["user_name"];
$mysql_qry = "SELECT `game_data` FROM `user_account_data` WHERE `username` = '$user_name';";
$result = mysqli_query($connection, $mysql_qry); 
if (! $result){
echo "Unable to extract data from database \n";
} 
else {
$data = mysqli_fetch_row($result);
echo $data[0];
}
?>
