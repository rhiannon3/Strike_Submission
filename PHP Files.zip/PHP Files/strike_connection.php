<?php 
$database_name = "strike";
$mysql_username = "root";
$mysql_password = "";
$server_name = "localhost";
$connection = mysqli_connect($server_name, $mysql_username, $mysql_password, $database_name);
if (!$connection){
echo "Connection unsucessful \n";
}
?>