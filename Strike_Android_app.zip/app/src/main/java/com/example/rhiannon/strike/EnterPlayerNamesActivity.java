package com.example.rhiannon.strike;
        import android.content.Intent;
        import android.os.Bundle;
        import android.support.design.widget.FloatingActionButton;
        import android.support.design.widget.Snackbar;
        import android.support.v7.app.AppCompatActivity;
        import android.support.v7.widget.Toolbar;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.RelativeLayout;

public class EnterPlayerNamesActivity extends AppCompatActivity {
    Button startGameButton;
    RelativeLayout layout1, layout2, layout3, layout4, layout5, layout6;
    EditText player1NameField, player2NameField, player3NameField, player4NameField, player5NameField, player6NameField;
    String username, numberOfPlayersString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_player_names);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        layout1 = (RelativeLayout) findViewById(R.id.layout1);
        layout2 = (RelativeLayout) findViewById(R.id.layout2);
        layout3 = (RelativeLayout) findViewById(R.id.layout3);
        layout4 = (RelativeLayout) findViewById(R.id.layout4);
        layout5 = (RelativeLayout) findViewById(R.id.layout5);
        layout6 = (RelativeLayout) findViewById(R.id.layout6);

        startGameButton = (Button) findViewById(R.id.startGameButton);
        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), ScoringActivity.class);
                intent.putExtra("Username", username);
                intent.putExtra("Number Of Players", numberOfPlayersString);
                intent.putExtra("Game Type", "New Game");

                switch (numberOfPlayersString) {
                    case "1":
                        intent.putExtra("Player 1 Name", player1NameField.getText().toString());
                        break;
                    case "2":
                        intent.putExtra("Player 1 Name", player1NameField.getText().toString());
                        intent.putExtra("Player 2 Name", player2NameField.getText().toString());
                        break;
                    case "3":
                        intent.putExtra("Player 1 Name", player1NameField.getText().toString());
                        intent.putExtra("Player 2 Name", player2NameField.getText().toString());
                        intent.putExtra("Player 3 Name", player3NameField.getText().toString());
                        break;
                    case "4":
                        intent.putExtra("Player 1 Name", player1NameField.getText().toString());
                        intent.putExtra("Player 2 Name", player2NameField.getText().toString());
                        intent.putExtra("Player 3 Name", player3NameField.getText().toString());
                        intent.putExtra("Player 4 Name", player4NameField.getText().toString());
                        break;
                    case "5":
                        intent.putExtra("Player 1 Name", player1NameField.getText().toString());
                        intent.putExtra("Player 2 Name", player2NameField.getText().toString());
                        intent.putExtra("Player 3 Name", player3NameField.getText().toString());
                        intent.putExtra("Player 4 Name", player4NameField.getText().toString());
                        intent.putExtra("Player 5 Name", player5NameField.getText().toString());
                        break;
                    case "6":
                        intent.putExtra("Player 1 Name", player1NameField.getText().toString());
                        intent.putExtra("Player 2 Name", player2NameField.getText().toString());
                        intent.putExtra("Player 3 Name", player3NameField.getText().toString());
                        intent.putExtra("Player 4 Name", player4NameField.getText().toString());
                        intent.putExtra("Player 5 Name", player5NameField.getText().toString());
                        intent.putExtra("Player 6 Name", player6NameField.getText().toString());
                        break;
                }

                startActivity(intent);
            }
        });

        Bundle extras = getIntent().getExtras();
        username = extras.getString("Username");
        numberOfPlayersString = extras.getString("Number of Players");
        player1NameField = (EditText) findViewById(R.id.userNameInputField1);
        switch (numberOfPlayersString){
            case "1":
                layout2.removeAllViewsInLayout();
                layout3.removeAllViewsInLayout();
                layout4.removeAllViewsInLayout();
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "2":
                player2NameField = (EditText) findViewById(R.id.userNameInputField2);
                layout3.removeAllViewsInLayout();
                layout4.removeAllViewsInLayout();
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "3":
                player2NameField = (EditText) findViewById(R.id.userNameInputField2);
                player3NameField = (EditText) findViewById(R.id.userNameInputField3);
                layout4.removeAllViewsInLayout();
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "4":
                player2NameField = (EditText) findViewById(R.id.userNameInputField2);
                player3NameField = (EditText) findViewById(R.id.userNameInputField3);
                player4NameField = (EditText) findViewById(R.id.userNameInputField4);
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "5":
                player2NameField = (EditText) findViewById(R.id.userNameInputField2);
                player3NameField = (EditText) findViewById(R.id.userNameInputField3);
                player4NameField = (EditText) findViewById(R.id.userNameInputField4);
                player5NameField = (EditText) findViewById(R.id.userNameInputField5);
                layout6.removeAllViewsInLayout();
                break;
            case "6":
                player2NameField = (EditText) findViewById(R.id.userNameInputField2);
                player3NameField = (EditText) findViewById(R.id.userNameInputField3);
                player4NameField = (EditText) findViewById(R.id.userNameInputField4);
                player5NameField = (EditText) findViewById(R.id.userNameInputField5);
                player6NameField = (EditText) findViewById(R.id.userNameInputField6);
                break;
        }


    }

}

