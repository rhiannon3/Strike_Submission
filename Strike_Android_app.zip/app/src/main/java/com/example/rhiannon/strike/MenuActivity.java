package com.example.rhiannon.strike;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

public class MenuActivity extends AppCompatActivity {

    Button startNewGameButton,logoutButton;
    String username;
    LoadGameDAO loadGameDAO;
    static String activity = "load game";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Obtain the buttons via ID and add the actionListener to each
        startNewGameButton = (Button) findViewById(R.id.startNewGameButton);
        startNewGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SelectNumberOfPlayersActivity.class);
                intent.putExtra("Username", username);
                startActivity(intent);
            }
        });

        Bundle extras = getIntent().getExtras();
        username = extras.getString("Username");

        logoutButton = (Button) findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public void OnLoadGame (View view){
        loadGameDAO = new LoadGameDAO(this);
        loadGameDAO.execute(activity, username);

    }
}

