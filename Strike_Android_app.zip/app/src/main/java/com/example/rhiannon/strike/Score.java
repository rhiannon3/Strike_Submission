package com.example.rhiannon.strike;

public class Score {
    // Declare the variables
    public int[] individualThrows;
    public int[] cumulativeFrameScores;
    public int cumulativeScore;
    public boolean isFinalised;
    public int scoredFrames;
    private int throwsMade;
    private boolean calculateSingleStrikeOfFrame9;
    public String[] scoreBoxFormats;
    String scoreData;

    // Define the conditions
    private String queuedFrameCondition;
    private static final String STANDARD = "Standard";
    private static final String SINGLESTRIKE = "SingleStrike";
    private static final String DOUBLESTRIKE = "DoubleStrike";
    private static final String TRIPLESTRIKE = "TripleStrike";
    private static final String SPARE = "Spare";
    private static final String BONUSTHROW = "BonusThrow";

    // Create the constructor
    public Score(){
        individualThrows = new int[21];
        cumulativeFrameScores = new int[10];
        cumulativeScore = 0;
        scoredFrames = 0;
        throwsMade = 0;
        isFinalised = false;
        queuedFrameCondition = STANDARD;
        calculateSingleStrikeOfFrame9 = false;
        scoreBoxFormats = new String[32];
        for (int index = 21; index < 31; index++){
            scoreBoxFormats[index] = "null";
        }
    }

    public Score(String loadedScoreData) {
        // loadedScoreData format = "throwsMade-scoredFrames-cumulativeScore-isFinalised-calculateSingleStrikeOfFrame9-individualThrowsData-cumulativeFrameScoresData-scoreBoxFrameCharactersData"
        String[] scoreData = loadedScoreData.split("-");
        throwsMade = Integer.parseInt(scoreData[0]);
        scoredFrames = Integer.parseInt(scoreData[1]);
        cumulativeScore = Integer.parseInt(scoreData[2]);
        isFinalised = Boolean.parseBoolean(scoreData[3]);
        calculateSingleStrikeOfFrame9 = Boolean.parseBoolean(scoreData[4]);
        String[] individualThrowsData = scoreData[5].split("~");
        individualThrows = new int[21];
        for (int index = 0; index < 21; index++){
            individualThrows[index] = Integer.parseInt(individualThrowsData[index]);
        }
        String[] cumulativeFrameScoresData = scoreData[6].split("~");
        cumulativeFrameScores = new int[10];
        for (int index = 0; index < 10; index++){
            cumulativeFrameScores[index] = Integer.parseInt(individualThrowsData[index]);
        }
        scoreBoxFormats = scoreData[7].split("~");
        queuedFrameCondition = scoreData[8];
    }

    // Create the method to update the score
    public void update (int pinsKnockedDown){
        // Add pinsKnockedDown to throwsMade
        individualThrows[throwsMade] = pinsKnockedDown;
        throwsMade++;
        // Check if special conditions apply because
        // the throw made was in Frame 10
        if (throwsMade <= 18){ // Frames 1-9: no special conditions apply
            // Check for a strike
            if (throwsMade % 2 == 1){
                // These pins were knocked down on the first throw of the frame
                if (pinsKnockedDown == 10){
                    // There was a strike
                    scoreBoxFormats[throwsMade-1] = "   ";
                    scoreBoxFormats[throwsMade] = "  X";
                    individualThrows[throwsMade] = 0;
                    throwsMade++;
                } else {
                    scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
                }
            }   else {
                // These pins were knocked down on the second throw of the frame
                if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] == 10){
                    // There was a strike
                    scoreBoxFormats[throwsMade-1] = "  /";
                } else {
                    scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
                }
            }
        } else if (throwsMade == 19){
            if (pinsKnockedDown == 10){
                // There was a strike
                scoreBoxFormats[throwsMade -1] = "  X";
            } else {
                scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
            }
        } else if (throwsMade == 20){
            // Check if the game is finished or if the user gets
            // the bonus throw
            if (individualThrows[18] + individualThrows[19] < 10){
                isFinalised = true;
                scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
            } else if (individualThrows[18] + individualThrows[19] == 10){
                // There was a spare or a strike followed by a throw where 0 pins were knocked down
                if (individualThrows[19] == 0){
                    // There was a strike followed by a throw where 0 pins were knocked down
                    scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
                } else {
                    // There was a spare
                    scoreBoxFormats[throwsMade-1] = "  /";
                }
            } else {
                // There was a strike followed by another throw with the potential to score a strike
                if (pinsKnockedDown == 10){
                    // There were two consecutive strikes
                    scoreBoxFormats[throwsMade -1] = "  X";
                } else {
                    scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
                }
            }
        } else {
            // This is the final possible throw of the frame
            isFinalised = true;
            if (individualThrows[19] + individualThrows[20] < 10){
                scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
            } else if (individualThrows[19] + individualThrows[20] == 10) {
                // There was a spare or a strike followed by a throw where 0 pins were knocked down
                if (individualThrows[20] == 0) {
                    // There was a strike followed by a throw where 0 pins were knocked down
                    scoreBoxFormats[throwsMade - 1] = "  " + Integer.toString(pinsKnockedDown);
                } else {
                    // There was a spare
                    scoreBoxFormats[throwsMade - 1] = "  /";
                }
            } else {
                if (pinsKnockedDown == 10){
                    scoreBoxFormats[throwsMade -1] = "  X";
                } else {
                    scoreBoxFormats[throwsMade-1] = "  " + Integer.toString(pinsKnockedDown);
                }
            }
        }
        checkFrameCanBeScored();
    }

    // Create the method that will check after which throws cumulativeFrameScores
    // and cumulativeScore need to be calculated
    private void checkFrameCanBeScored() {
        if (throwsMade <= 18){ // Frames 1-9: no special conditions apply
            switch(queuedFrameCondition){
                case STANDARD:
                    // Calculate a standard frame after the frame is completed
                    if (throwsMade % 2 == 0){// Throw 2 of the most recent frame has been made
                        if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){ // Neither a spare or strike was thrown
                            calculateFrame(STANDARD);
                            // Note that queuedFrameCondition does not change
                            queuedFrameCondition = STANDARD;
                        } else if (individualThrows[throwsMade-2] == 10){ // A strike was thrown
                            // Another frame is now required to calculate the score of this frame
                            queuedFrameCondition= SINGLESTRIKE;
                        } else { // A spare was thrown
                            // Another frame is now required to calculate the score of this frame
                            queuedFrameCondition = SPARE;
                        }
                    }
                    break;
                case SPARE:
                    // Calculate a spare frame after the 1st throw of the next frame is completed
                    // Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
                    if (throwsMade % 2 == 0){ // A strike was thrown
                        calculateFrame(SPARE);
                        queuedFrameCondition = SINGLESTRIKE;
                    } else { // Either a standard frame or a spare will be thrown
                        calculateFrame(SPARE);
                        // If a spare is thrown it will be detected after throw 2 is made
                        queuedFrameCondition = STANDARD;
                    }
                    break;
                case SINGLESTRIKE:
                    // Calculate a single strike after the next frame is completed
                    if (throwsMade % 2 == 0){
                        if (individualThrows[throwsMade-2] + individualThrows[throwsMade-1] < 10){
                            // Condition 1: The single strike is followed by a standard frame
                            calculateFrame(SINGLESTRIKE);
                            queuedFrameCondition = STANDARD;
                            calculateFrame(STANDARD);
                        } else if (individualThrows[throwsMade-2] == 10){
                            // Condition 2: The single strike is followed by another strike
                            queuedFrameCondition = DOUBLESTRIKE;
                        } else {
                            // Condition 3: The single strike is followed by spare
                            calculateFrame(SINGLESTRIKE);
                            queuedFrameCondition = SPARE;
                        }
                    }
                    break;
                case DOUBLESTRIKE:
                    // Calculate a double strike after the 1st throw of the next frame is completed
                    // Note: If a strike is thrown, there is no throw 2, ie. throwsMade will then be even
                    if (throwsMade % 2 == 0){ // A triple strike was achieved
                        calculateFrame(TRIPLESTRIKE);
                        // Note that queuedFrameCondition does not change
                        queuedFrameCondition = DOUBLESTRIKE;
                    } else {
                        calculateFrame(DOUBLESTRIKE);
                        queuedFrameCondition = SINGLESTRIKE;
                    }
                    break;
            }
        } else if (throwsMade == 19){ // Frame 10, Throw 1
            // Special Conditions Apply
            switch(queuedFrameCondition){
                case STANDARD:
                    // The STANDARD case can only be followed by a single strike or a standard case
                    if (individualThrows[throwsMade -1] == 10){
                        queuedFrameCondition = SINGLESTRIKE;
                    } else {
                        queuedFrameCondition = STANDARD;
                    }
                    break;
                case SPARE:
                    calculateFrame(SPARE);
                    // The SPARE case can only be followed by a single strike or a standard case
                    if (individualThrows[throwsMade -1] == 10){
                        queuedFrameCondition = SINGLESTRIKE;
                    } else {
                        queuedFrameCondition = STANDARD;
                    }
                    break;
                case SINGLESTRIKE:
                    // THE SINGLESTRIKE can be followed by a standard or double strike
                    calculateSingleStrikeOfFrame9 = true;
                    if (individualThrows[throwsMade - 1] == 10){
                        queuedFrameCondition = DOUBLESTRIKE;
                    } else {
                        queuedFrameCondition = STANDARD;
                    }

                    break;
                case DOUBLESTRIKE:
                    if (individualThrows[throwsMade -1] == 10){ // A triple strike was achieved
                        calculateFrame(TRIPLESTRIKE);
                        // Note that queuedFrameCondition does not change
                        queuedFrameCondition = DOUBLESTRIKE;
                    } else {
                        calculateFrame(DOUBLESTRIKE);
                        queuedFrameCondition = SINGLESTRIKE;
                    }
                    break;
            }
        } else if (throwsMade == 20){ // Frame 10, Throw 2
            // Special Conditions Apply
            if (calculateSingleStrikeOfFrame9){
                calculateFrame(SINGLESTRIKE);
            }
            switch(queuedFrameCondition){
                case STANDARD:
                    // A Standard may be followed by either be a standard or a spare
                    if (individualThrows[18] + individualThrows[19] == 10){
                        queuedFrameCondition = SPARE;
                    } else {
                        calculateFrame(STANDARD);
                    }
                    break;
                case SINGLESTRIKE:
                    if (individualThrows[19] == 10){
                        queuedFrameCondition = DOUBLESTRIKE;
                    }
                    break;
                case DOUBLESTRIKE:
                    if (individualThrows[throwsMade -1] == 10){ // A triple strike was achieved
                        calculateFrame(TRIPLESTRIKE);
                        // Note that queuedFrameCondition does not change
                        queuedFrameCondition = DOUBLESTRIKE;
                    } else {
                        calculateFrame(DOUBLESTRIKE);
                        queuedFrameCondition = SINGLESTRIKE;
                    }
                    break;
            }
        } else { // The player has received the bonus throw
            calculateFrame(BONUSTHROW);
        }

    }

    private void calculateFrame(String condition) {
        int mostRecentThrow = throwsMade - 1;
        switch(condition){
            case STANDARD:
                cumulativeScore += individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
                break;
            case SPARE:
                if (throwsMade % 2 == 0){ // The spare was followed by a strike
                    cumulativeScore += 20;
                } else {
                    cumulativeScore += 10 + individualThrows[mostRecentThrow];
                }
                break;
            case SINGLESTRIKE:
                cumulativeScore += 10 + individualThrows[mostRecentThrow - 1] + individualThrows[mostRecentThrow];
                break;
            case DOUBLESTRIKE:
                cumulativeScore += 20 + individualThrows[mostRecentThrow];
                break;
            case TRIPLESTRIKE:
                cumulativeScore += 30;
                break;
            case BONUSTHROW:
                cumulativeScore += individualThrows[18] + individualThrows[19] + individualThrows[20];
                break;
        }
        cumulativeFrameScores[scoredFrames] = cumulativeScore;
        scoredFrames++;
        if (scoredFrames == 10){
            isFinalised = true;
            if (cumulativeScore < 100){
                scoreBoxFormats[scoredFrames + 20] = "     " + Integer.toString(cumulativeScore);
            } else {
                scoreBoxFormats[scoredFrames + 20] = "    " + Integer.toString(cumulativeScore);
            }
        } else {
            if (cumulativeScore < 100){
                scoreBoxFormats[scoredFrames + 20] = "    " + Integer.toString(cumulativeScore);
            } else {
                scoreBoxFormats[scoredFrames + 20] = "  " + Integer.toString(cumulativeScore);
            }
        }
        scoreBoxFormats[31] = Integer.toString(cumulativeScore);
    }

    @Override
    public String toString(){
        // scoreData format = "throwsMade-scoredFrames-cumulativeScore-isFinalised-calculateSingleStrikeOfFrame9-individualThrowsData-cumulativeFrameScoresData-scoreBoxFrameCharactersData-queuedFrameCondition"        // Add the integer variables to scoreData
        scoreData = "";
        scoreData += Integer.toString(throwsMade) + "-" + Integer.toString(scoredFrames) + "-" + Integer.toString(cumulativeScore) + "-";
        // Add the boolean variables to scoreData
        scoreData += Boolean.toString(isFinalised) + "-" + Boolean.toString(calculateSingleStrikeOfFrame9) + "-";
        // Turn the int[] variables into formatted Strings
        String individualThrowsData = "";
        individualThrowsData += Integer.toString(individualThrows[0]);
        for (int index = 1; index < 21; index++){
            individualThrowsData += "~" + Integer.toString(individualThrows[index]);
        }
        String cumulativeFrameScoresData = "";
        cumulativeFrameScoresData += Integer.toString(cumulativeFrameScores[0]);
        for (int index = 1; index < 10; index++){
            cumulativeFrameScoresData += "~" + Integer.toString(cumulativeFrameScores[index]);
        }
        // Add the int[] variables to scoreData
        scoreData += individualThrowsData + "-" + cumulativeFrameScoresData + "-";
        // TODO Turn the String[] variable into formattedStrings
        String formattedScoreBoxData = "";
        formattedScoreBoxData += scoreBoxFormats[0];
        for (int index = 1; index < 32; index++){
            formattedScoreBoxData += "~" + scoreBoxFormats[index];
        }
        scoreData += formattedScoreBoxData;
        scoreData += "-" + queuedFrameCondition;
        return scoreData;
    }

    public int getLastThrowMade(){
        return individualThrows[throwsMade - 1];
    }
}
