package com.example.rhiannon.strike;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

public class SelectNumberOfPlayersActivity extends AppCompatActivity {

    Button button1, button2, button3, button4, button5, button6;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_number_of_players);

        Bundle extras = getIntent().getExtras();
        username = extras.getString("Username");

        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EnterPlayerNamesActivity.class);
                // Put Extra
                intent.putExtra("Number of Players", "1");
                intent.putExtra("Username", username);
                startActivity(intent);
            }
        });

        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EnterPlayerNamesActivity.class);
                // Put Extra
                intent.putExtra("Number of Players", "2");
                intent.putExtra("Username", username);
                startActivity(intent);
            }
        });

        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EnterPlayerNamesActivity.class);
                // Put Extra
                intent.putExtra("Number of Players", "3");
                intent.putExtra("Username", username);
                startActivity(intent);
            }
        });

        button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EnterPlayerNamesActivity.class);
                // Put Extra
                intent.putExtra("Number of Players", "4");
                intent.putExtra("Username", username);
                startActivity(intent);
            }
        });

        button5 =(Button) findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EnterPlayerNamesActivity.class);
                // Put Extra
                intent.putExtra("Number of Players", "5");
                intent.putExtra("Username", username);
                startActivity(intent);
            }
        });

        button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EnterPlayerNamesActivity.class);
                // Put Extra
                intent.putExtra("Number of Players", "6");
                intent.putExtra("Username", username);
                startActivity(intent);
            }
        });

    }
}

