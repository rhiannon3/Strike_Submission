package com.example.rhiannon.strike;

/**
 * Created by rhian on 12/10/2016.
 */

public class Scoreboard {
    Player[] players;

    public Scoreboard (Player players[]){
        this.players = players;
    }

    @Override
    public String toString(){
        // gameData format = "currentFrame,throwOfFrame,currentPlayerIndex,playersData"
        String scoreboardData = "";
        scoreboardData += players[0].toString();
        for (int index = 1; index < players.length; index++){
            scoreboardData += ";" + players[index].toString();
        }
        return scoreboardData;
    }

    public int getLastThrowValue(int currentPlayerIndex){
        return players[currentPlayerIndex].score.getLastThrowMade();
    }

}

