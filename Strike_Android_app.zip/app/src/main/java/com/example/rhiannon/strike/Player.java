package com.example.rhiannon.strike;

/**
 * Created by rhian on 12/10/2016.
 */


public class Player {
    String name;
    Score score;

    public Player (String name) {
        // TODO Implement Functionality
        this.name = name;
        score = new Score();
    }

    @Override
    public String toString(){
        // gameData format = "name:scoreData"
        String playerData = name;
        playerData += ":" + score.toString();
        return playerData;
    }

}

