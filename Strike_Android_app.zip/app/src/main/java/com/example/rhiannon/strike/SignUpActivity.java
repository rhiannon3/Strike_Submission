package com.example.rhiannon.strike;

        import android.app.AlertDialog;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;

public class SignUpActivity extends AppCompatActivity {

    EditText usernameField, passwordField, confirmPasswordField;
    String username, password, confirmedPassword;
    static String activity = "sign_up";
    SignUpDAO signUpDAO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        usernameField = (EditText) findViewById(R.id.userNameInputField);
        passwordField = (EditText) findViewById(R.id.passwordInputField);
        confirmPasswordField = (EditText) findViewById(R.id.confirmPasswordInputField) ;

    }

    public void onSignUp (View view) {
        username = usernameField.getText().toString();
        password = passwordField.getText().toString();
        confirmedPassword = confirmPasswordField.getText().toString();
        if (password.equals(confirmedPassword)){
            signUpDAO = new SignUpDAO(this);
            signUpDAO.execute(activity, username, password);
        } else {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("Sign Up Status");
            alertDialog.setMessage("The passwords do not match");
            alertDialog.show();
        }


    }
}
