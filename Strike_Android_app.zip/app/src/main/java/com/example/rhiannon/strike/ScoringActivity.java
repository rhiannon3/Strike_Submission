package com.example.rhiannon.strike;

        import android.content.Intent;
        import android.content.pm.ActivityInfo;
        import android.os.Bundle;
        import android.support.design.widget.FloatingActionButton;
        import android.support.design.widget.Snackbar;
        import android.support.v7.app.AppCompatActivity;
        import android.support.v7.widget.Toolbar;
        import android.view.View;
        import android.widget.Button;
        import android.widget.LinearLayout;
        import android.widget.TextView;

public class ScoringActivity extends AppCompatActivity {

    Button button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, saveButton, quitButton;
    LinearLayout layout1, layout2, layout3, layout4, layout5, layout6;
    TextView player1NameTV, player2NameTV, player3NameTV, player4NameTV, player5NameTV, player6NameTV;
    String username, gameData, numberOfPlayersString, gameType;
    int numberOfPlayers, currentFrame, throwOfFrame, currentPlayerIndex, throwFieldsIndex;
    Player[] players;
    Bundle extras;
    static String activity = "save game";
    SaveGameDAO saveGameDAO;
    Scoreboard scoreboard;
    TextView[][] guiIndividualThrowFields;
    TextView[][] guiFrameScoreFields;
    TextView[] scoreFields;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoring);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        // Set the layout to be landscape
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setUpButtons();
        // Get extras and set up the game state variables as well as generating the scoreboard and players array
        getExtras();


    }

    private void setUpGUIScoreboard(){
        guiIndividualThrowFields = new TextView[numberOfPlayers][21];
        guiFrameScoreFields = new TextView[numberOfPlayers][10];
        scoreFields = new TextView[numberOfPlayers];
        switch (numberOfPlayers){
            case 1:
                guiIndividualThrowFields[0][0] = (TextView) findViewById(R.id.player1individualThrows1TV);
                guiIndividualThrowFields[0][1] = (TextView) findViewById(R.id.player1individualThrows2TV);
                guiIndividualThrowFields[0][2] = (TextView) findViewById(R.id.player1individualThrows3TV);
                guiIndividualThrowFields[0][3] = (TextView) findViewById(R.id.player1individualThrows4TV);
                guiIndividualThrowFields[0][4] = (TextView) findViewById(R.id.player1individualThrows5TV);
                guiIndividualThrowFields[0][5] = (TextView) findViewById(R.id.player1individualThrows6TV);
                guiIndividualThrowFields[0][6] = (TextView) findViewById(R.id.player1individualThrows7TV);
                guiIndividualThrowFields[0][7] = (TextView) findViewById(R.id.player1individualThrows8TV);
                guiIndividualThrowFields[0][8] = (TextView) findViewById(R.id.player1individualThrows9TV);
                guiIndividualThrowFields[0][9] = (TextView) findViewById(R.id.player1individualThrows10TV);
                guiIndividualThrowFields[0][10] = (TextView) findViewById(R.id.player1individualThrows11TV);
                guiIndividualThrowFields[0][11] = (TextView) findViewById(R.id.player1individualThrows12TV);
                guiIndividualThrowFields[0][12] = (TextView) findViewById(R.id.player1individualThrows13TV);
                guiIndividualThrowFields[0][13] = (TextView) findViewById(R.id.player1individualThrows14TV);
                guiIndividualThrowFields[0][14] = (TextView) findViewById(R.id.player1individualThrows15TV);
                guiIndividualThrowFields[0][15] = (TextView) findViewById(R.id.player1individualThrows16TV);
                guiIndividualThrowFields[0][16] = (TextView) findViewById(R.id.player1individualThrows17TV);
                guiIndividualThrowFields[0][17] = (TextView) findViewById(R.id.player1individualThrows18TV);
                guiIndividualThrowFields[0][18] = (TextView) findViewById(R.id.player1individualThrows19TV);
                guiIndividualThrowFields[0][19] = (TextView) findViewById(R.id.player1individualThrows20TV);
                guiIndividualThrowFields[0][20] = (TextView) findViewById(R.id.player1individualThrows21TV);
                guiFrameScoreFields[0][0] = (TextView) findViewById(R.id.player1frameScores1TV);
                guiFrameScoreFields[0][1] = (TextView) findViewById(R.id.player1frameScores2TV);
                guiFrameScoreFields[0][2] = (TextView) findViewById(R.id.player1frameScores3TV);
                guiFrameScoreFields[0][3] = (TextView) findViewById(R.id.player1frameScores4TV);
                guiFrameScoreFields[0][4] = (TextView) findViewById(R.id.player1frameScores5TV);
                guiFrameScoreFields[0][5] = (TextView) findViewById(R.id.player1frameScores6TV);
                guiFrameScoreFields[0][6] = (TextView) findViewById(R.id.player1frameScores7TV);
                guiFrameScoreFields[0][7] = (TextView) findViewById(R.id.player1frameScores8TV);
                guiFrameScoreFields[0][8] = (TextView) findViewById(R.id.player1frameScores9TV);
                guiFrameScoreFields[0][9] = (TextView) findViewById(R.id.player1frameScores10TV);
                scoreFields[0] = (TextView) findViewById(R.id.player1cumulativeScoreTV);
                break;
            case 2:
                guiIndividualThrowFields[0][0] = (TextView) findViewById(R.id.player1individualThrows1TV);
                guiIndividualThrowFields[0][1] = (TextView) findViewById(R.id.player1individualThrows2TV);
                guiIndividualThrowFields[0][2] = (TextView) findViewById(R.id.player1individualThrows3TV);
                guiIndividualThrowFields[0][3] = (TextView) findViewById(R.id.player1individualThrows4TV);
                guiIndividualThrowFields[0][4] = (TextView) findViewById(R.id.player1individualThrows5TV);
                guiIndividualThrowFields[0][5] = (TextView) findViewById(R.id.player1individualThrows6TV);
                guiIndividualThrowFields[0][6] = (TextView) findViewById(R.id.player1individualThrows7TV);
                guiIndividualThrowFields[0][7] = (TextView) findViewById(R.id.player1individualThrows8TV);
                guiIndividualThrowFields[0][8] = (TextView) findViewById(R.id.player1individualThrows9TV);
                guiIndividualThrowFields[0][9] = (TextView) findViewById(R.id.player1individualThrows10TV);
                guiIndividualThrowFields[0][10] = (TextView) findViewById(R.id.player1individualThrows11TV);
                guiIndividualThrowFields[0][11] = (TextView) findViewById(R.id.player1individualThrows12TV);
                guiIndividualThrowFields[0][12] = (TextView) findViewById(R.id.player1individualThrows13TV);
                guiIndividualThrowFields[0][13] = (TextView) findViewById(R.id.player1individualThrows14TV);
                guiIndividualThrowFields[0][14] = (TextView) findViewById(R.id.player1individualThrows15TV);
                guiIndividualThrowFields[0][15] = (TextView) findViewById(R.id.player1individualThrows16TV);
                guiIndividualThrowFields[0][16] = (TextView) findViewById(R.id.player1individualThrows17TV);
                guiIndividualThrowFields[0][17] = (TextView) findViewById(R.id.player1individualThrows18TV);
                guiIndividualThrowFields[0][18] = (TextView) findViewById(R.id.player1individualThrows19TV);
                guiIndividualThrowFields[0][19] = (TextView) findViewById(R.id.player1individualThrows20TV);
                guiIndividualThrowFields[0][20] = (TextView) findViewById(R.id.player1individualThrows21TV);
                guiIndividualThrowFields[1][0] = (TextView) findViewById(R.id.player2individualThrows1TV);
                guiIndividualThrowFields[1][1] = (TextView) findViewById(R.id.player2individualThrows2TV);
                guiIndividualThrowFields[1][2] = (TextView) findViewById(R.id.player2individualThrows3TV);
                guiIndividualThrowFields[1][3] = (TextView) findViewById(R.id.player2individualThrows4TV);
                guiIndividualThrowFields[1][4] = (TextView) findViewById(R.id.player2individualThrows5TV);
                guiIndividualThrowFields[1][5] = (TextView) findViewById(R.id.player2individualThrows6TV);
                guiIndividualThrowFields[1][6] = (TextView) findViewById(R.id.player2individualThrows7TV);
                guiIndividualThrowFields[1][7] = (TextView) findViewById(R.id.player2individualThrows8TV);
                guiIndividualThrowFields[1][8] = (TextView) findViewById(R.id.player2individualThrows9TV);
                guiIndividualThrowFields[1][9] = (TextView) findViewById(R.id.player2individualThrows10TV);
                guiIndividualThrowFields[1][10] = (TextView) findViewById(R.id.player2individualThrows11TV);
                guiIndividualThrowFields[1][11] = (TextView) findViewById(R.id.player2individualThrows12TV);
                guiIndividualThrowFields[1][12] = (TextView) findViewById(R.id.player2individualThrows13TV);
                guiIndividualThrowFields[1][13] = (TextView) findViewById(R.id.player2individualThrows14TV);
                guiIndividualThrowFields[1][14] = (TextView) findViewById(R.id.player2individualThrows15TV);
                guiIndividualThrowFields[1][15] = (TextView) findViewById(R.id.player2individualThrows16TV);
                guiIndividualThrowFields[1][16] = (TextView) findViewById(R.id.player2individualThrows17TV);
                guiIndividualThrowFields[1][17] = (TextView) findViewById(R.id.player2individualThrows18TV);
                guiIndividualThrowFields[1][18] = (TextView) findViewById(R.id.player2individualThrows19TV);
                guiIndividualThrowFields[1][19] = (TextView) findViewById(R.id.player2individualThrows20TV);
                guiIndividualThrowFields[1][20] = (TextView) findViewById(R.id.player2individualThrows21TV);
                guiFrameScoreFields[0][0] = (TextView) findViewById(R.id.player1frameScores1TV);
                guiFrameScoreFields[0][1] = (TextView) findViewById(R.id.player1frameScores2TV);
                guiFrameScoreFields[0][2] = (TextView) findViewById(R.id.player1frameScores3TV);
                guiFrameScoreFields[0][3] = (TextView) findViewById(R.id.player1frameScores4TV);
                guiFrameScoreFields[0][4] = (TextView) findViewById(R.id.player1frameScores5TV);
                guiFrameScoreFields[0][5] = (TextView) findViewById(R.id.player1frameScores6TV);
                guiFrameScoreFields[0][6] = (TextView) findViewById(R.id.player1frameScores7TV);
                guiFrameScoreFields[0][7] = (TextView) findViewById(R.id.player1frameScores8TV);
                guiFrameScoreFields[0][8] = (TextView) findViewById(R.id.player1frameScores9TV);
                guiFrameScoreFields[0][9] = (TextView) findViewById(R.id.player1frameScores10TV);
                guiFrameScoreFields[1][0] = (TextView) findViewById(R.id.player2frameScores1TV);
                guiFrameScoreFields[1][1] = (TextView) findViewById(R.id.player2frameScores2TV);
                guiFrameScoreFields[1][2] = (TextView) findViewById(R.id.player2frameScores3TV);
                guiFrameScoreFields[1][3] = (TextView) findViewById(R.id.player2frameScores4TV);
                guiFrameScoreFields[1][4] = (TextView) findViewById(R.id.player2frameScores5TV);
                guiFrameScoreFields[1][5] = (TextView) findViewById(R.id.player2frameScores6TV);
                guiFrameScoreFields[1][6] = (TextView) findViewById(R.id.player2frameScores7TV);
                guiFrameScoreFields[1][7] = (TextView) findViewById(R.id.player2frameScores8TV);
                guiFrameScoreFields[1][8] = (TextView) findViewById(R.id.player2frameScores9TV);
                guiFrameScoreFields[1][9] = (TextView) findViewById(R.id.player2frameScores10TV);
                scoreFields[0] = (TextView) findViewById(R.id.player1cumulativeScoreTV);
                scoreFields[1] = (TextView) findViewById(R.id.player2cumulativeScoreTV);
                break;
            case 3:
                guiIndividualThrowFields[0][0] = (TextView) findViewById(R.id.player1individualThrows1TV);
                guiIndividualThrowFields[0][1] = (TextView) findViewById(R.id.player1individualThrows2TV);
                guiIndividualThrowFields[0][2] = (TextView) findViewById(R.id.player1individualThrows3TV);
                guiIndividualThrowFields[0][3] = (TextView) findViewById(R.id.player1individualThrows4TV);
                guiIndividualThrowFields[0][4] = (TextView) findViewById(R.id.player1individualThrows5TV);
                guiIndividualThrowFields[0][5] = (TextView) findViewById(R.id.player1individualThrows6TV);
                guiIndividualThrowFields[0][6] = (TextView) findViewById(R.id.player1individualThrows7TV);
                guiIndividualThrowFields[0][7] = (TextView) findViewById(R.id.player1individualThrows8TV);
                guiIndividualThrowFields[0][8] = (TextView) findViewById(R.id.player1individualThrows9TV);
                guiIndividualThrowFields[0][9] = (TextView) findViewById(R.id.player1individualThrows10TV);
                guiIndividualThrowFields[0][10] = (TextView) findViewById(R.id.player1individualThrows11TV);
                guiIndividualThrowFields[0][11] = (TextView) findViewById(R.id.player1individualThrows12TV);
                guiIndividualThrowFields[0][12] = (TextView) findViewById(R.id.player1individualThrows13TV);
                guiIndividualThrowFields[0][13] = (TextView) findViewById(R.id.player1individualThrows14TV);
                guiIndividualThrowFields[0][14] = (TextView) findViewById(R.id.player1individualThrows15TV);
                guiIndividualThrowFields[0][15] = (TextView) findViewById(R.id.player1individualThrows16TV);
                guiIndividualThrowFields[0][16] = (TextView) findViewById(R.id.player1individualThrows17TV);
                guiIndividualThrowFields[0][17] = (TextView) findViewById(R.id.player1individualThrows18TV);
                guiIndividualThrowFields[0][18] = (TextView) findViewById(R.id.player1individualThrows19TV);
                guiIndividualThrowFields[0][19] = (TextView) findViewById(R.id.player1individualThrows20TV);
                guiIndividualThrowFields[0][20] = (TextView) findViewById(R.id.player1individualThrows21TV);
                guiIndividualThrowFields[1][0] = (TextView) findViewById(R.id.player2individualThrows1TV);
                guiIndividualThrowFields[1][1] = (TextView) findViewById(R.id.player2individualThrows2TV);
                guiIndividualThrowFields[1][2] = (TextView) findViewById(R.id.player2individualThrows3TV);
                guiIndividualThrowFields[1][3] = (TextView) findViewById(R.id.player2individualThrows4TV);
                guiIndividualThrowFields[1][4] = (TextView) findViewById(R.id.player2individualThrows5TV);
                guiIndividualThrowFields[1][5] = (TextView) findViewById(R.id.player2individualThrows6TV);
                guiIndividualThrowFields[1][6] = (TextView) findViewById(R.id.player2individualThrows7TV);
                guiIndividualThrowFields[1][7] = (TextView) findViewById(R.id.player2individualThrows8TV);
                guiIndividualThrowFields[1][8] = (TextView) findViewById(R.id.player2individualThrows9TV);
                guiIndividualThrowFields[1][9] = (TextView) findViewById(R.id.player2individualThrows10TV);
                guiIndividualThrowFields[1][10] = (TextView) findViewById(R.id.player2individualThrows11TV);
                guiIndividualThrowFields[1][11] = (TextView) findViewById(R.id.player2individualThrows12TV);
                guiIndividualThrowFields[1][12] = (TextView) findViewById(R.id.player2individualThrows13TV);
                guiIndividualThrowFields[1][13] = (TextView) findViewById(R.id.player2individualThrows14TV);
                guiIndividualThrowFields[1][14] = (TextView) findViewById(R.id.player2individualThrows15TV);
                guiIndividualThrowFields[1][15] = (TextView) findViewById(R.id.player2individualThrows16TV);
                guiIndividualThrowFields[1][16] = (TextView) findViewById(R.id.player2individualThrows17TV);
                guiIndividualThrowFields[1][17] = (TextView) findViewById(R.id.player2individualThrows18TV);
                guiIndividualThrowFields[1][18] = (TextView) findViewById(R.id.player2individualThrows19TV);
                guiIndividualThrowFields[1][19] = (TextView) findViewById(R.id.player2individualThrows20TV);
                guiIndividualThrowFields[1][20] = (TextView) findViewById(R.id.player2individualThrows21TV);
                guiIndividualThrowFields[2][0] = (TextView) findViewById(R.id.player3individualThrows1TV);
                guiIndividualThrowFields[2][1] = (TextView) findViewById(R.id.player3individualThrows2TV);
                guiIndividualThrowFields[2][2] = (TextView) findViewById(R.id.player3individualThrows3TV);
                guiIndividualThrowFields[2][3] = (TextView) findViewById(R.id.player3individualThrows4TV);
                guiIndividualThrowFields[2][4] = (TextView) findViewById(R.id.player3individualThrows5TV);
                guiIndividualThrowFields[2][5] = (TextView) findViewById(R.id.player3individualThrows6TV);
                guiIndividualThrowFields[2][6] = (TextView) findViewById(R.id.player3individualThrows7TV);
                guiIndividualThrowFields[2][7] = (TextView) findViewById(R.id.player3individualThrows8TV);
                guiIndividualThrowFields[2][8] = (TextView) findViewById(R.id.player3individualThrows9TV);
                guiIndividualThrowFields[2][9] = (TextView) findViewById(R.id.player3individualThrows10TV);
                guiIndividualThrowFields[2][10] = (TextView) findViewById(R.id.player3individualThrows11TV);
                guiIndividualThrowFields[2][11] = (TextView) findViewById(R.id.player3individualThrows12TV);
                guiIndividualThrowFields[2][12] = (TextView) findViewById(R.id.player3individualThrows13TV);
                guiIndividualThrowFields[2][13] = (TextView) findViewById(R.id.player3individualThrows14TV);
                guiIndividualThrowFields[2][14] = (TextView) findViewById(R.id.player3individualThrows15TV);
                guiIndividualThrowFields[2][15] = (TextView) findViewById(R.id.player3individualThrows16TV);
                guiIndividualThrowFields[2][16] = (TextView) findViewById(R.id.player3individualThrows17TV);
                guiIndividualThrowFields[2][17] = (TextView) findViewById(R.id.player3individualThrows18TV);
                guiIndividualThrowFields[2][18] = (TextView) findViewById(R.id.player3individualThrows19TV);
                guiIndividualThrowFields[2][19] = (TextView) findViewById(R.id.player3individualThrows20TV);
                guiIndividualThrowFields[2][20] = (TextView) findViewById(R.id.player3individualThrows21TV);
                guiFrameScoreFields[0][0] = (TextView) findViewById(R.id.player1frameScores1TV);
                guiFrameScoreFields[0][1] = (TextView) findViewById(R.id.player1frameScores2TV);
                guiFrameScoreFields[0][2] = (TextView) findViewById(R.id.player1frameScores3TV);
                guiFrameScoreFields[0][3] = (TextView) findViewById(R.id.player1frameScores4TV);
                guiFrameScoreFields[0][4] = (TextView) findViewById(R.id.player1frameScores5TV);
                guiFrameScoreFields[0][5] = (TextView) findViewById(R.id.player1frameScores6TV);
                guiFrameScoreFields[0][6] = (TextView) findViewById(R.id.player1frameScores7TV);
                guiFrameScoreFields[0][7] = (TextView) findViewById(R.id.player1frameScores8TV);
                guiFrameScoreFields[0][8] = (TextView) findViewById(R.id.player1frameScores9TV);
                guiFrameScoreFields[0][9] = (TextView) findViewById(R.id.player1frameScores10TV);
                guiFrameScoreFields[1][0] = (TextView) findViewById(R.id.player2frameScores1TV);
                guiFrameScoreFields[1][1] = (TextView) findViewById(R.id.player2frameScores2TV);
                guiFrameScoreFields[1][2] = (TextView) findViewById(R.id.player2frameScores3TV);
                guiFrameScoreFields[1][3] = (TextView) findViewById(R.id.player2frameScores4TV);
                guiFrameScoreFields[1][4] = (TextView) findViewById(R.id.player2frameScores5TV);
                guiFrameScoreFields[1][5] = (TextView) findViewById(R.id.player2frameScores6TV);
                guiFrameScoreFields[1][6] = (TextView) findViewById(R.id.player2frameScores7TV);
                guiFrameScoreFields[1][7] = (TextView) findViewById(R.id.player2frameScores8TV);
                guiFrameScoreFields[1][8] = (TextView) findViewById(R.id.player2frameScores9TV);
                guiFrameScoreFields[1][9] = (TextView) findViewById(R.id.player2frameScores10TV);
                guiFrameScoreFields[2][0] = (TextView) findViewById(R.id.player3frameScores1TV);
                guiFrameScoreFields[2][1] = (TextView) findViewById(R.id.player3frameScores2TV);
                guiFrameScoreFields[2][2] = (TextView) findViewById(R.id.player3frameScores3TV);
                guiFrameScoreFields[2][3] = (TextView) findViewById(R.id.player3frameScores4TV);
                guiFrameScoreFields[2][4] = (TextView) findViewById(R.id.player3frameScores5TV);
                guiFrameScoreFields[2][5] = (TextView) findViewById(R.id.player3frameScores6TV);
                guiFrameScoreFields[2][6] = (TextView) findViewById(R.id.player3frameScores7TV);
                guiFrameScoreFields[2][7] = (TextView) findViewById(R.id.player3frameScores8TV);
                guiFrameScoreFields[2][8] = (TextView) findViewById(R.id.player3frameScores9TV);
                guiFrameScoreFields[2][9] = (TextView) findViewById(R.id.player3frameScores10TV);
                scoreFields[0] = (TextView) findViewById(R.id.player1cumulativeScoreTV);
                scoreFields[1] = (TextView) findViewById(R.id.player2cumulativeScoreTV);
                scoreFields[2] = (TextView) findViewById(R.id.player3cumulativeScoreTV);
                break;
            case 4:
                guiIndividualThrowFields[0][0] = (TextView) findViewById(R.id.player1individualThrows1TV);
                guiIndividualThrowFields[0][1] = (TextView) findViewById(R.id.player1individualThrows2TV);
                guiIndividualThrowFields[0][2] = (TextView) findViewById(R.id.player1individualThrows3TV);
                guiIndividualThrowFields[0][3] = (TextView) findViewById(R.id.player1individualThrows4TV);
                guiIndividualThrowFields[0][4] = (TextView) findViewById(R.id.player1individualThrows5TV);
                guiIndividualThrowFields[0][5] = (TextView) findViewById(R.id.player1individualThrows6TV);
                guiIndividualThrowFields[0][6] = (TextView) findViewById(R.id.player1individualThrows7TV);
                guiIndividualThrowFields[0][7] = (TextView) findViewById(R.id.player1individualThrows8TV);
                guiIndividualThrowFields[0][8] = (TextView) findViewById(R.id.player1individualThrows9TV);
                guiIndividualThrowFields[0][9] = (TextView) findViewById(R.id.player1individualThrows10TV);
                guiIndividualThrowFields[0][10] = (TextView) findViewById(R.id.player1individualThrows11TV);
                guiIndividualThrowFields[0][11] = (TextView) findViewById(R.id.player1individualThrows12TV);
                guiIndividualThrowFields[0][12] = (TextView) findViewById(R.id.player1individualThrows13TV);
                guiIndividualThrowFields[0][13] = (TextView) findViewById(R.id.player1individualThrows14TV);
                guiIndividualThrowFields[0][14] = (TextView) findViewById(R.id.player1individualThrows15TV);
                guiIndividualThrowFields[0][15] = (TextView) findViewById(R.id.player1individualThrows16TV);
                guiIndividualThrowFields[0][16] = (TextView) findViewById(R.id.player1individualThrows17TV);
                guiIndividualThrowFields[0][17] = (TextView) findViewById(R.id.player1individualThrows18TV);
                guiIndividualThrowFields[0][18] = (TextView) findViewById(R.id.player1individualThrows19TV);
                guiIndividualThrowFields[0][19] = (TextView) findViewById(R.id.player1individualThrows20TV);
                guiIndividualThrowFields[0][20] = (TextView) findViewById(R.id.player1individualThrows21TV);
                guiIndividualThrowFields[1][0] = (TextView) findViewById(R.id.player2individualThrows1TV);
                guiIndividualThrowFields[1][1] = (TextView) findViewById(R.id.player2individualThrows2TV);
                guiIndividualThrowFields[1][2] = (TextView) findViewById(R.id.player2individualThrows3TV);
                guiIndividualThrowFields[1][3] = (TextView) findViewById(R.id.player2individualThrows4TV);
                guiIndividualThrowFields[1][4] = (TextView) findViewById(R.id.player2individualThrows5TV);
                guiIndividualThrowFields[1][5] = (TextView) findViewById(R.id.player2individualThrows6TV);
                guiIndividualThrowFields[1][6] = (TextView) findViewById(R.id.player2individualThrows7TV);
                guiIndividualThrowFields[1][7] = (TextView) findViewById(R.id.player2individualThrows8TV);
                guiIndividualThrowFields[1][8] = (TextView) findViewById(R.id.player2individualThrows9TV);
                guiIndividualThrowFields[1][9] = (TextView) findViewById(R.id.player2individualThrows10TV);
                guiIndividualThrowFields[1][10] = (TextView) findViewById(R.id.player2individualThrows11TV);
                guiIndividualThrowFields[1][11] = (TextView) findViewById(R.id.player2individualThrows12TV);
                guiIndividualThrowFields[1][12] = (TextView) findViewById(R.id.player2individualThrows13TV);
                guiIndividualThrowFields[1][13] = (TextView) findViewById(R.id.player2individualThrows14TV);
                guiIndividualThrowFields[1][14] = (TextView) findViewById(R.id.player2individualThrows15TV);
                guiIndividualThrowFields[1][15] = (TextView) findViewById(R.id.player2individualThrows16TV);
                guiIndividualThrowFields[1][16] = (TextView) findViewById(R.id.player2individualThrows17TV);
                guiIndividualThrowFields[1][17] = (TextView) findViewById(R.id.player2individualThrows18TV);
                guiIndividualThrowFields[1][18] = (TextView) findViewById(R.id.player2individualThrows19TV);
                guiIndividualThrowFields[1][19] = (TextView) findViewById(R.id.player2individualThrows20TV);
                guiIndividualThrowFields[1][20] = (TextView) findViewById(R.id.player2individualThrows21TV);
                guiIndividualThrowFields[2][0] = (TextView) findViewById(R.id.player3individualThrows1TV);
                guiIndividualThrowFields[2][1] = (TextView) findViewById(R.id.player3individualThrows2TV);
                guiIndividualThrowFields[2][2] = (TextView) findViewById(R.id.player3individualThrows3TV);
                guiIndividualThrowFields[2][3] = (TextView) findViewById(R.id.player3individualThrows4TV);
                guiIndividualThrowFields[2][4] = (TextView) findViewById(R.id.player3individualThrows5TV);
                guiIndividualThrowFields[2][5] = (TextView) findViewById(R.id.player3individualThrows6TV);
                guiIndividualThrowFields[2][6] = (TextView) findViewById(R.id.player3individualThrows7TV);
                guiIndividualThrowFields[2][7] = (TextView) findViewById(R.id.player3individualThrows8TV);
                guiIndividualThrowFields[2][8] = (TextView) findViewById(R.id.player3individualThrows9TV);
                guiIndividualThrowFields[2][9] = (TextView) findViewById(R.id.player3individualThrows10TV);
                guiIndividualThrowFields[2][10] = (TextView) findViewById(R.id.player3individualThrows11TV);
                guiIndividualThrowFields[2][11] = (TextView) findViewById(R.id.player3individualThrows12TV);
                guiIndividualThrowFields[2][12] = (TextView) findViewById(R.id.player3individualThrows13TV);
                guiIndividualThrowFields[2][13] = (TextView) findViewById(R.id.player3individualThrows14TV);
                guiIndividualThrowFields[2][14] = (TextView) findViewById(R.id.player3individualThrows15TV);
                guiIndividualThrowFields[2][15] = (TextView) findViewById(R.id.player3individualThrows16TV);
                guiIndividualThrowFields[2][16] = (TextView) findViewById(R.id.player3individualThrows17TV);
                guiIndividualThrowFields[2][17] = (TextView) findViewById(R.id.player3individualThrows18TV);
                guiIndividualThrowFields[2][18] = (TextView) findViewById(R.id.player3individualThrows19TV);
                guiIndividualThrowFields[2][19] = (TextView) findViewById(R.id.player3individualThrows20TV);
                guiIndividualThrowFields[2][20] = (TextView) findViewById(R.id.player3individualThrows21TV);
                guiIndividualThrowFields[3][0] = (TextView) findViewById(R.id.player4individualThrows1TV);
                guiIndividualThrowFields[3][1] = (TextView) findViewById(R.id.player4individualThrows2TV);
                guiIndividualThrowFields[3][2] = (TextView) findViewById(R.id.player4individualThrows3TV);
                guiIndividualThrowFields[3][3] = (TextView) findViewById(R.id.player4individualThrows4TV);
                guiIndividualThrowFields[3][4] = (TextView) findViewById(R.id.player4individualThrows5TV);
                guiIndividualThrowFields[3][5] = (TextView) findViewById(R.id.player4individualThrows6TV);
                guiIndividualThrowFields[3][6] = (TextView) findViewById(R.id.player4individualThrows7TV);
                guiIndividualThrowFields[3][7] = (TextView) findViewById(R.id.player4individualThrows8TV);
                guiIndividualThrowFields[3][8] = (TextView) findViewById(R.id.player4individualThrows9TV);
                guiIndividualThrowFields[3][9] = (TextView) findViewById(R.id.player4individualThrows10TV);
                guiIndividualThrowFields[3][10] = (TextView) findViewById(R.id.player4individualThrows11TV);
                guiIndividualThrowFields[3][11] = (TextView) findViewById(R.id.player4individualThrows12TV);
                guiIndividualThrowFields[3][12] = (TextView) findViewById(R.id.player4individualThrows13TV);
                guiIndividualThrowFields[3][13] = (TextView) findViewById(R.id.player4individualThrows14TV);
                guiIndividualThrowFields[3][14] = (TextView) findViewById(R.id.player4individualThrows15TV);
                guiIndividualThrowFields[3][15] = (TextView) findViewById(R.id.player4individualThrows16TV);
                guiIndividualThrowFields[3][16] = (TextView) findViewById(R.id.player4individualThrows17TV);
                guiIndividualThrowFields[3][17] = (TextView) findViewById(R.id.player4individualThrows18TV);
                guiIndividualThrowFields[3][18] = (TextView) findViewById(R.id.player4individualThrows19TV);
                guiIndividualThrowFields[3][19] = (TextView) findViewById(R.id.player4individualThrows20TV);
                guiIndividualThrowFields[3][20] = (TextView) findViewById(R.id.player4individualThrows21TV);
                guiFrameScoreFields[0][0] = (TextView) findViewById(R.id.player1frameScores1TV);
                guiFrameScoreFields[0][1] = (TextView) findViewById(R.id.player1frameScores2TV);
                guiFrameScoreFields[0][2] = (TextView) findViewById(R.id.player1frameScores3TV);
                guiFrameScoreFields[0][3] = (TextView) findViewById(R.id.player1frameScores4TV);
                guiFrameScoreFields[0][4] = (TextView) findViewById(R.id.player1frameScores5TV);
                guiFrameScoreFields[0][5] = (TextView) findViewById(R.id.player1frameScores6TV);
                guiFrameScoreFields[0][6] = (TextView) findViewById(R.id.player1frameScores7TV);
                guiFrameScoreFields[0][7] = (TextView) findViewById(R.id.player1frameScores8TV);
                guiFrameScoreFields[0][8] = (TextView) findViewById(R.id.player1frameScores9TV);
                guiFrameScoreFields[0][9] = (TextView) findViewById(R.id.player1frameScores10TV);
                guiFrameScoreFields[1][0] = (TextView) findViewById(R.id.player2frameScores1TV);
                guiFrameScoreFields[1][1] = (TextView) findViewById(R.id.player2frameScores2TV);
                guiFrameScoreFields[1][2] = (TextView) findViewById(R.id.player2frameScores3TV);
                guiFrameScoreFields[1][3] = (TextView) findViewById(R.id.player2frameScores4TV);
                guiFrameScoreFields[1][4] = (TextView) findViewById(R.id.player2frameScores5TV);
                guiFrameScoreFields[1][5] = (TextView) findViewById(R.id.player2frameScores6TV);
                guiFrameScoreFields[1][6] = (TextView) findViewById(R.id.player2frameScores7TV);
                guiFrameScoreFields[1][7] = (TextView) findViewById(R.id.player2frameScores8TV);
                guiFrameScoreFields[1][8] = (TextView) findViewById(R.id.player2frameScores9TV);
                guiFrameScoreFields[1][9] = (TextView) findViewById(R.id.player2frameScores10TV);
                guiFrameScoreFields[2][0] = (TextView) findViewById(R.id.player3frameScores1TV);
                guiFrameScoreFields[2][1] = (TextView) findViewById(R.id.player3frameScores2TV);
                guiFrameScoreFields[2][2] = (TextView) findViewById(R.id.player3frameScores3TV);
                guiFrameScoreFields[2][3] = (TextView) findViewById(R.id.player3frameScores4TV);
                guiFrameScoreFields[2][4] = (TextView) findViewById(R.id.player3frameScores5TV);
                guiFrameScoreFields[2][5] = (TextView) findViewById(R.id.player3frameScores6TV);
                guiFrameScoreFields[2][6] = (TextView) findViewById(R.id.player3frameScores7TV);
                guiFrameScoreFields[2][7] = (TextView) findViewById(R.id.player3frameScores8TV);
                guiFrameScoreFields[2][8] = (TextView) findViewById(R.id.player3frameScores9TV);
                guiFrameScoreFields[2][9] = (TextView) findViewById(R.id.player3frameScores10TV);
                guiFrameScoreFields[3][0] = (TextView) findViewById(R.id.player4frameScores1TV);
                guiFrameScoreFields[3][1] = (TextView) findViewById(R.id.player4frameScores2TV);
                guiFrameScoreFields[3][2] = (TextView) findViewById(R.id.player4frameScores3TV);
                guiFrameScoreFields[3][3] = (TextView) findViewById(R.id.player4frameScores4TV);
                guiFrameScoreFields[3][4] = (TextView) findViewById(R.id.player4frameScores5TV);
                guiFrameScoreFields[3][5] = (TextView) findViewById(R.id.player4frameScores6TV);
                guiFrameScoreFields[3][6] = (TextView) findViewById(R.id.player4frameScores7TV);
                guiFrameScoreFields[3][7] = (TextView) findViewById(R.id.player4frameScores8TV);
                guiFrameScoreFields[3][8] = (TextView) findViewById(R.id.player4frameScores9TV);
                guiFrameScoreFields[3][9] = (TextView) findViewById(R.id.player4frameScores10TV);
                scoreFields[0] = (TextView) findViewById(R.id.player1cumulativeScoreTV);
                scoreFields[1] = (TextView) findViewById(R.id.player2cumulativeScoreTV);
                scoreFields[2] = (TextView) findViewById(R.id.player3cumulativeScoreTV);
                scoreFields[3] = (TextView) findViewById(R.id.player4cumulativeScoreTV);
                break;
            case 5:
                guiIndividualThrowFields[0][0] = (TextView) findViewById(R.id.player1individualThrows1TV);
                guiIndividualThrowFields[0][1] = (TextView) findViewById(R.id.player1individualThrows2TV);
                guiIndividualThrowFields[0][2] = (TextView) findViewById(R.id.player1individualThrows3TV);
                guiIndividualThrowFields[0][3] = (TextView) findViewById(R.id.player1individualThrows4TV);
                guiIndividualThrowFields[0][4] = (TextView) findViewById(R.id.player1individualThrows5TV);
                guiIndividualThrowFields[0][5] = (TextView) findViewById(R.id.player1individualThrows6TV);
                guiIndividualThrowFields[0][6] = (TextView) findViewById(R.id.player1individualThrows7TV);
                guiIndividualThrowFields[0][7] = (TextView) findViewById(R.id.player1individualThrows8TV);
                guiIndividualThrowFields[0][8] = (TextView) findViewById(R.id.player1individualThrows9TV);
                guiIndividualThrowFields[0][9] = (TextView) findViewById(R.id.player1individualThrows10TV);
                guiIndividualThrowFields[0][10] = (TextView) findViewById(R.id.player1individualThrows11TV);
                guiIndividualThrowFields[0][11] = (TextView) findViewById(R.id.player1individualThrows12TV);
                guiIndividualThrowFields[0][12] = (TextView) findViewById(R.id.player1individualThrows13TV);
                guiIndividualThrowFields[0][13] = (TextView) findViewById(R.id.player1individualThrows14TV);
                guiIndividualThrowFields[0][14] = (TextView) findViewById(R.id.player1individualThrows15TV);
                guiIndividualThrowFields[0][15] = (TextView) findViewById(R.id.player1individualThrows16TV);
                guiIndividualThrowFields[0][16] = (TextView) findViewById(R.id.player1individualThrows17TV);
                guiIndividualThrowFields[0][17] = (TextView) findViewById(R.id.player1individualThrows18TV);
                guiIndividualThrowFields[0][18] = (TextView) findViewById(R.id.player1individualThrows19TV);
                guiIndividualThrowFields[0][19] = (TextView) findViewById(R.id.player1individualThrows20TV);
                guiIndividualThrowFields[0][20] = (TextView) findViewById(R.id.player1individualThrows21TV);
                guiIndividualThrowFields[1][0] = (TextView) findViewById(R.id.player2individualThrows1TV);
                guiIndividualThrowFields[1][1] = (TextView) findViewById(R.id.player2individualThrows2TV);
                guiIndividualThrowFields[1][2] = (TextView) findViewById(R.id.player2individualThrows3TV);
                guiIndividualThrowFields[1][3] = (TextView) findViewById(R.id.player2individualThrows4TV);
                guiIndividualThrowFields[1][4] = (TextView) findViewById(R.id.player2individualThrows5TV);
                guiIndividualThrowFields[1][5] = (TextView) findViewById(R.id.player2individualThrows6TV);
                guiIndividualThrowFields[1][6] = (TextView) findViewById(R.id.player2individualThrows7TV);
                guiIndividualThrowFields[1][7] = (TextView) findViewById(R.id.player2individualThrows8TV);
                guiIndividualThrowFields[1][8] = (TextView) findViewById(R.id.player2individualThrows9TV);
                guiIndividualThrowFields[1][9] = (TextView) findViewById(R.id.player2individualThrows10TV);
                guiIndividualThrowFields[1][10] = (TextView) findViewById(R.id.player2individualThrows11TV);
                guiIndividualThrowFields[1][11] = (TextView) findViewById(R.id.player2individualThrows12TV);
                guiIndividualThrowFields[1][12] = (TextView) findViewById(R.id.player2individualThrows13TV);
                guiIndividualThrowFields[1][13] = (TextView) findViewById(R.id.player2individualThrows14TV);
                guiIndividualThrowFields[1][14] = (TextView) findViewById(R.id.player2individualThrows15TV);
                guiIndividualThrowFields[1][15] = (TextView) findViewById(R.id.player2individualThrows16TV);
                guiIndividualThrowFields[1][16] = (TextView) findViewById(R.id.player2individualThrows17TV);
                guiIndividualThrowFields[1][17] = (TextView) findViewById(R.id.player2individualThrows18TV);
                guiIndividualThrowFields[1][18] = (TextView) findViewById(R.id.player2individualThrows19TV);
                guiIndividualThrowFields[1][19] = (TextView) findViewById(R.id.player2individualThrows20TV);
                guiIndividualThrowFields[1][20] = (TextView) findViewById(R.id.player2individualThrows21TV);
                guiIndividualThrowFields[2][0] = (TextView) findViewById(R.id.player3individualThrows1TV);
                guiIndividualThrowFields[2][1] = (TextView) findViewById(R.id.player3individualThrows2TV);
                guiIndividualThrowFields[2][2] = (TextView) findViewById(R.id.player3individualThrows3TV);
                guiIndividualThrowFields[2][3] = (TextView) findViewById(R.id.player3individualThrows4TV);
                guiIndividualThrowFields[2][4] = (TextView) findViewById(R.id.player3individualThrows5TV);
                guiIndividualThrowFields[2][5] = (TextView) findViewById(R.id.player3individualThrows6TV);
                guiIndividualThrowFields[2][6] = (TextView) findViewById(R.id.player3individualThrows7TV);
                guiIndividualThrowFields[2][7] = (TextView) findViewById(R.id.player3individualThrows8TV);
                guiIndividualThrowFields[2][8] = (TextView) findViewById(R.id.player3individualThrows9TV);
                guiIndividualThrowFields[2][9] = (TextView) findViewById(R.id.player3individualThrows10TV);
                guiIndividualThrowFields[2][10] = (TextView) findViewById(R.id.player3individualThrows11TV);
                guiIndividualThrowFields[2][11] = (TextView) findViewById(R.id.player3individualThrows12TV);
                guiIndividualThrowFields[2][12] = (TextView) findViewById(R.id.player3individualThrows13TV);
                guiIndividualThrowFields[2][13] = (TextView) findViewById(R.id.player3individualThrows14TV);
                guiIndividualThrowFields[2][14] = (TextView) findViewById(R.id.player3individualThrows15TV);
                guiIndividualThrowFields[2][15] = (TextView) findViewById(R.id.player3individualThrows16TV);
                guiIndividualThrowFields[2][16] = (TextView) findViewById(R.id.player3individualThrows17TV);
                guiIndividualThrowFields[2][17] = (TextView) findViewById(R.id.player3individualThrows18TV);
                guiIndividualThrowFields[2][18] = (TextView) findViewById(R.id.player3individualThrows19TV);
                guiIndividualThrowFields[2][19] = (TextView) findViewById(R.id.player3individualThrows20TV);
                guiIndividualThrowFields[2][20] = (TextView) findViewById(R.id.player3individualThrows21TV);
                guiIndividualThrowFields[3][0] = (TextView) findViewById(R.id.player4individualThrows1TV);
                guiIndividualThrowFields[3][1] = (TextView) findViewById(R.id.player4individualThrows2TV);
                guiIndividualThrowFields[3][2] = (TextView) findViewById(R.id.player4individualThrows3TV);
                guiIndividualThrowFields[3][3] = (TextView) findViewById(R.id.player4individualThrows4TV);
                guiIndividualThrowFields[3][4] = (TextView) findViewById(R.id.player4individualThrows5TV);
                guiIndividualThrowFields[3][5] = (TextView) findViewById(R.id.player4individualThrows6TV);
                guiIndividualThrowFields[3][6] = (TextView) findViewById(R.id.player4individualThrows7TV);
                guiIndividualThrowFields[3][7] = (TextView) findViewById(R.id.player4individualThrows8TV);
                guiIndividualThrowFields[3][8] = (TextView) findViewById(R.id.player4individualThrows9TV);
                guiIndividualThrowFields[3][9] = (TextView) findViewById(R.id.player4individualThrows10TV);
                guiIndividualThrowFields[3][10] = (TextView) findViewById(R.id.player4individualThrows11TV);
                guiIndividualThrowFields[3][11] = (TextView) findViewById(R.id.player4individualThrows12TV);
                guiIndividualThrowFields[3][12] = (TextView) findViewById(R.id.player4individualThrows13TV);
                guiIndividualThrowFields[3][13] = (TextView) findViewById(R.id.player4individualThrows14TV);
                guiIndividualThrowFields[3][14] = (TextView) findViewById(R.id.player4individualThrows15TV);
                guiIndividualThrowFields[3][15] = (TextView) findViewById(R.id.player4individualThrows16TV);
                guiIndividualThrowFields[3][16] = (TextView) findViewById(R.id.player4individualThrows17TV);
                guiIndividualThrowFields[3][17] = (TextView) findViewById(R.id.player4individualThrows18TV);
                guiIndividualThrowFields[3][18] = (TextView) findViewById(R.id.player4individualThrows19TV);
                guiIndividualThrowFields[3][19] = (TextView) findViewById(R.id.player4individualThrows20TV);
                guiIndividualThrowFields[3][20] = (TextView) findViewById(R.id.player4individualThrows21TV);
                guiIndividualThrowFields[4][0] = (TextView) findViewById(R.id.player5individualThrows1TV);
                guiIndividualThrowFields[4][1] = (TextView) findViewById(R.id.player5individualThrows2TV);
                guiIndividualThrowFields[4][2] = (TextView) findViewById(R.id.player5individualThrows3TV);
                guiIndividualThrowFields[4][3] = (TextView) findViewById(R.id.player5individualThrows4TV);
                guiIndividualThrowFields[4][4] = (TextView) findViewById(R.id.player5individualThrows5TV);
                guiIndividualThrowFields[4][5] = (TextView) findViewById(R.id.player5individualThrows6TV);
                guiIndividualThrowFields[4][6] = (TextView) findViewById(R.id.player5individualThrows7TV);
                guiIndividualThrowFields[4][7] = (TextView) findViewById(R.id.player5individualThrows8TV);
                guiIndividualThrowFields[4][8] = (TextView) findViewById(R.id.player5individualThrows9TV);
                guiIndividualThrowFields[4][9] = (TextView) findViewById(R.id.player5individualThrows10TV);
                guiIndividualThrowFields[4][10] = (TextView) findViewById(R.id.player5individualThrows11TV);
                guiIndividualThrowFields[4][11] = (TextView) findViewById(R.id.player5individualThrows12TV);
                guiIndividualThrowFields[4][12] = (TextView) findViewById(R.id.player5individualThrows13TV);
                guiIndividualThrowFields[4][13] = (TextView) findViewById(R.id.player5individualThrows14TV);
                guiIndividualThrowFields[4][14] = (TextView) findViewById(R.id.player5individualThrows15TV);
                guiIndividualThrowFields[4][15] = (TextView) findViewById(R.id.player5individualThrows16TV);
                guiIndividualThrowFields[4][16] = (TextView) findViewById(R.id.player5individualThrows17TV);
                guiIndividualThrowFields[4][17] = (TextView) findViewById(R.id.player5individualThrows18TV);
                guiIndividualThrowFields[4][18] = (TextView) findViewById(R.id.player5individualThrows19TV);
                guiIndividualThrowFields[4][19] = (TextView) findViewById(R.id.player5individualThrows20TV);
                guiIndividualThrowFields[4][20] = (TextView) findViewById(R.id.player5individualThrows21TV);
                guiFrameScoreFields[0][0] = (TextView) findViewById(R.id.player1frameScores1TV);
                guiFrameScoreFields[0][1] = (TextView) findViewById(R.id.player1frameScores2TV);
                guiFrameScoreFields[0][2] = (TextView) findViewById(R.id.player1frameScores3TV);
                guiFrameScoreFields[0][3] = (TextView) findViewById(R.id.player1frameScores4TV);
                guiFrameScoreFields[0][4] = (TextView) findViewById(R.id.player1frameScores5TV);
                guiFrameScoreFields[0][5] = (TextView) findViewById(R.id.player1frameScores6TV);
                guiFrameScoreFields[0][6] = (TextView) findViewById(R.id.player1frameScores7TV);
                guiFrameScoreFields[0][7] = (TextView) findViewById(R.id.player1frameScores8TV);
                guiFrameScoreFields[0][8] = (TextView) findViewById(R.id.player1frameScores9TV);
                guiFrameScoreFields[0][9] = (TextView) findViewById(R.id.player1frameScores10TV);
                guiFrameScoreFields[1][0] = (TextView) findViewById(R.id.player2frameScores1TV);
                guiFrameScoreFields[1][1] = (TextView) findViewById(R.id.player2frameScores2TV);
                guiFrameScoreFields[1][2] = (TextView) findViewById(R.id.player2frameScores3TV);
                guiFrameScoreFields[1][3] = (TextView) findViewById(R.id.player2frameScores4TV);
                guiFrameScoreFields[1][4] = (TextView) findViewById(R.id.player2frameScores5TV);
                guiFrameScoreFields[1][5] = (TextView) findViewById(R.id.player2frameScores6TV);
                guiFrameScoreFields[1][6] = (TextView) findViewById(R.id.player2frameScores7TV);
                guiFrameScoreFields[1][7] = (TextView) findViewById(R.id.player2frameScores8TV);
                guiFrameScoreFields[1][8] = (TextView) findViewById(R.id.player2frameScores9TV);
                guiFrameScoreFields[1][9] = (TextView) findViewById(R.id.player2frameScores10TV);
                guiFrameScoreFields[2][0] = (TextView) findViewById(R.id.player3frameScores1TV);
                guiFrameScoreFields[2][1] = (TextView) findViewById(R.id.player3frameScores2TV);
                guiFrameScoreFields[2][2] = (TextView) findViewById(R.id.player3frameScores3TV);
                guiFrameScoreFields[2][3] = (TextView) findViewById(R.id.player3frameScores4TV);
                guiFrameScoreFields[2][4] = (TextView) findViewById(R.id.player3frameScores5TV);
                guiFrameScoreFields[2][5] = (TextView) findViewById(R.id.player3frameScores6TV);
                guiFrameScoreFields[2][6] = (TextView) findViewById(R.id.player3frameScores7TV);
                guiFrameScoreFields[2][7] = (TextView) findViewById(R.id.player3frameScores8TV);
                guiFrameScoreFields[2][8] = (TextView) findViewById(R.id.player3frameScores9TV);
                guiFrameScoreFields[2][9] = (TextView) findViewById(R.id.player3frameScores10TV);
                guiFrameScoreFields[3][0] = (TextView) findViewById(R.id.player4frameScores1TV);
                guiFrameScoreFields[3][1] = (TextView) findViewById(R.id.player4frameScores2TV);
                guiFrameScoreFields[3][2] = (TextView) findViewById(R.id.player4frameScores3TV);
                guiFrameScoreFields[3][3] = (TextView) findViewById(R.id.player4frameScores4TV);
                guiFrameScoreFields[3][4] = (TextView) findViewById(R.id.player4frameScores5TV);
                guiFrameScoreFields[3][5] = (TextView) findViewById(R.id.player4frameScores6TV);
                guiFrameScoreFields[3][6] = (TextView) findViewById(R.id.player4frameScores7TV);
                guiFrameScoreFields[3][7] = (TextView) findViewById(R.id.player4frameScores8TV);
                guiFrameScoreFields[3][8] = (TextView) findViewById(R.id.player4frameScores9TV);
                guiFrameScoreFields[3][9] = (TextView) findViewById(R.id.player4frameScores10TV);
                guiFrameScoreFields[4][0] = (TextView) findViewById(R.id.player5frameScores1TV);
                guiFrameScoreFields[4][1] = (TextView) findViewById(R.id.player5frameScores2TV);
                guiFrameScoreFields[4][2] = (TextView) findViewById(R.id.player5frameScores3TV);
                guiFrameScoreFields[4][3] = (TextView) findViewById(R.id.player5frameScores4TV);
                guiFrameScoreFields[4][4] = (TextView) findViewById(R.id.player5frameScores5TV);
                guiFrameScoreFields[4][5] = (TextView) findViewById(R.id.player5frameScores6TV);
                guiFrameScoreFields[4][6] = (TextView) findViewById(R.id.player5frameScores7TV);
                guiFrameScoreFields[4][7] = (TextView) findViewById(R.id.player5frameScores8TV);
                guiFrameScoreFields[4][8] = (TextView) findViewById(R.id.player5frameScores9TV);
                guiFrameScoreFields[4][9] = (TextView) findViewById(R.id.player5frameScores10TV);
                scoreFields[0] = (TextView) findViewById(R.id.player1cumulativeScoreTV);
                scoreFields[1] = (TextView) findViewById(R.id.player2cumulativeScoreTV);
                scoreFields[2] = (TextView) findViewById(R.id.player3cumulativeScoreTV);
                scoreFields[3] = (TextView) findViewById(R.id.player4cumulativeScoreTV);
                scoreFields[4] = (TextView) findViewById(R.id.player5cumulativeScoreTV);
                break;
            case 6:
                guiIndividualThrowFields[0][0] = (TextView) findViewById(R.id.player1individualThrows1TV);
                guiIndividualThrowFields[0][1] = (TextView) findViewById(R.id.player1individualThrows2TV);
                guiIndividualThrowFields[0][2] = (TextView) findViewById(R.id.player1individualThrows3TV);
                guiIndividualThrowFields[0][3] = (TextView) findViewById(R.id.player1individualThrows4TV);
                guiIndividualThrowFields[0][4] = (TextView) findViewById(R.id.player1individualThrows5TV);
                guiIndividualThrowFields[0][5] = (TextView) findViewById(R.id.player1individualThrows6TV);
                guiIndividualThrowFields[0][6] = (TextView) findViewById(R.id.player1individualThrows7TV);
                guiIndividualThrowFields[0][7] = (TextView) findViewById(R.id.player1individualThrows8TV);
                guiIndividualThrowFields[0][8] = (TextView) findViewById(R.id.player1individualThrows9TV);
                guiIndividualThrowFields[0][9] = (TextView) findViewById(R.id.player1individualThrows10TV);
                guiIndividualThrowFields[0][10] = (TextView) findViewById(R.id.player1individualThrows11TV);
                guiIndividualThrowFields[0][11] = (TextView) findViewById(R.id.player1individualThrows12TV);
                guiIndividualThrowFields[0][12] = (TextView) findViewById(R.id.player1individualThrows13TV);
                guiIndividualThrowFields[0][13] = (TextView) findViewById(R.id.player1individualThrows14TV);
                guiIndividualThrowFields[0][14] = (TextView) findViewById(R.id.player1individualThrows15TV);
                guiIndividualThrowFields[0][15] = (TextView) findViewById(R.id.player1individualThrows16TV);
                guiIndividualThrowFields[0][16] = (TextView) findViewById(R.id.player1individualThrows17TV);
                guiIndividualThrowFields[0][17] = (TextView) findViewById(R.id.player1individualThrows18TV);
                guiIndividualThrowFields[0][18] = (TextView) findViewById(R.id.player1individualThrows19TV);
                guiIndividualThrowFields[0][19] = (TextView) findViewById(R.id.player1individualThrows20TV);
                guiIndividualThrowFields[0][20] = (TextView) findViewById(R.id.player1individualThrows21TV);
                guiIndividualThrowFields[1][0] = (TextView) findViewById(R.id.player2individualThrows1TV);
                guiIndividualThrowFields[1][1] = (TextView) findViewById(R.id.player2individualThrows2TV);
                guiIndividualThrowFields[1][2] = (TextView) findViewById(R.id.player2individualThrows3TV);
                guiIndividualThrowFields[1][3] = (TextView) findViewById(R.id.player2individualThrows4TV);
                guiIndividualThrowFields[1][4] = (TextView) findViewById(R.id.player2individualThrows5TV);
                guiIndividualThrowFields[1][5] = (TextView) findViewById(R.id.player2individualThrows6TV);
                guiIndividualThrowFields[1][6] = (TextView) findViewById(R.id.player2individualThrows7TV);
                guiIndividualThrowFields[1][7] = (TextView) findViewById(R.id.player2individualThrows8TV);
                guiIndividualThrowFields[1][8] = (TextView) findViewById(R.id.player2individualThrows9TV);
                guiIndividualThrowFields[1][9] = (TextView) findViewById(R.id.player2individualThrows10TV);
                guiIndividualThrowFields[1][10] = (TextView) findViewById(R.id.player2individualThrows11TV);
                guiIndividualThrowFields[1][11] = (TextView) findViewById(R.id.player2individualThrows12TV);
                guiIndividualThrowFields[1][12] = (TextView) findViewById(R.id.player2individualThrows13TV);
                guiIndividualThrowFields[1][13] = (TextView) findViewById(R.id.player2individualThrows14TV);
                guiIndividualThrowFields[1][14] = (TextView) findViewById(R.id.player2individualThrows15TV);
                guiIndividualThrowFields[1][15] = (TextView) findViewById(R.id.player2individualThrows16TV);
                guiIndividualThrowFields[1][16] = (TextView) findViewById(R.id.player2individualThrows17TV);
                guiIndividualThrowFields[1][17] = (TextView) findViewById(R.id.player2individualThrows18TV);
                guiIndividualThrowFields[1][18] = (TextView) findViewById(R.id.player2individualThrows19TV);
                guiIndividualThrowFields[1][19] = (TextView) findViewById(R.id.player2individualThrows20TV);
                guiIndividualThrowFields[1][20] = (TextView) findViewById(R.id.player2individualThrows21TV);
                guiIndividualThrowFields[2][0] = (TextView) findViewById(R.id.player3individualThrows1TV);
                guiIndividualThrowFields[2][1] = (TextView) findViewById(R.id.player3individualThrows2TV);
                guiIndividualThrowFields[2][2] = (TextView) findViewById(R.id.player3individualThrows3TV);
                guiIndividualThrowFields[2][3] = (TextView) findViewById(R.id.player3individualThrows4TV);
                guiIndividualThrowFields[2][4] = (TextView) findViewById(R.id.player3individualThrows5TV);
                guiIndividualThrowFields[2][5] = (TextView) findViewById(R.id.player3individualThrows6TV);
                guiIndividualThrowFields[2][6] = (TextView) findViewById(R.id.player3individualThrows7TV);
                guiIndividualThrowFields[2][7] = (TextView) findViewById(R.id.player3individualThrows8TV);
                guiIndividualThrowFields[2][8] = (TextView) findViewById(R.id.player3individualThrows9TV);
                guiIndividualThrowFields[2][9] = (TextView) findViewById(R.id.player3individualThrows10TV);
                guiIndividualThrowFields[2][10] = (TextView) findViewById(R.id.player3individualThrows11TV);
                guiIndividualThrowFields[2][11] = (TextView) findViewById(R.id.player3individualThrows12TV);
                guiIndividualThrowFields[2][12] = (TextView) findViewById(R.id.player3individualThrows13TV);
                guiIndividualThrowFields[2][13] = (TextView) findViewById(R.id.player3individualThrows14TV);
                guiIndividualThrowFields[2][14] = (TextView) findViewById(R.id.player3individualThrows15TV);
                guiIndividualThrowFields[2][15] = (TextView) findViewById(R.id.player3individualThrows16TV);
                guiIndividualThrowFields[2][16] = (TextView) findViewById(R.id.player3individualThrows17TV);
                guiIndividualThrowFields[2][17] = (TextView) findViewById(R.id.player3individualThrows18TV);
                guiIndividualThrowFields[2][18] = (TextView) findViewById(R.id.player3individualThrows19TV);
                guiIndividualThrowFields[2][19] = (TextView) findViewById(R.id.player3individualThrows20TV);
                guiIndividualThrowFields[2][20] = (TextView) findViewById(R.id.player3individualThrows21TV);
                guiIndividualThrowFields[3][0] = (TextView) findViewById(R.id.player4individualThrows1TV);
                guiIndividualThrowFields[3][1] = (TextView) findViewById(R.id.player4individualThrows2TV);
                guiIndividualThrowFields[3][2] = (TextView) findViewById(R.id.player4individualThrows3TV);
                guiIndividualThrowFields[3][3] = (TextView) findViewById(R.id.player4individualThrows4TV);
                guiIndividualThrowFields[3][4] = (TextView) findViewById(R.id.player4individualThrows5TV);
                guiIndividualThrowFields[3][5] = (TextView) findViewById(R.id.player4individualThrows6TV);
                guiIndividualThrowFields[3][6] = (TextView) findViewById(R.id.player4individualThrows7TV);
                guiIndividualThrowFields[3][7] = (TextView) findViewById(R.id.player4individualThrows8TV);
                guiIndividualThrowFields[3][8] = (TextView) findViewById(R.id.player4individualThrows9TV);
                guiIndividualThrowFields[3][9] = (TextView) findViewById(R.id.player4individualThrows10TV);
                guiIndividualThrowFields[3][10] = (TextView) findViewById(R.id.player4individualThrows11TV);
                guiIndividualThrowFields[3][11] = (TextView) findViewById(R.id.player4individualThrows12TV);
                guiIndividualThrowFields[3][12] = (TextView) findViewById(R.id.player4individualThrows13TV);
                guiIndividualThrowFields[3][13] = (TextView) findViewById(R.id.player4individualThrows14TV);
                guiIndividualThrowFields[3][14] = (TextView) findViewById(R.id.player4individualThrows15TV);
                guiIndividualThrowFields[3][15] = (TextView) findViewById(R.id.player4individualThrows16TV);
                guiIndividualThrowFields[3][16] = (TextView) findViewById(R.id.player4individualThrows17TV);
                guiIndividualThrowFields[3][17] = (TextView) findViewById(R.id.player4individualThrows18TV);
                guiIndividualThrowFields[3][18] = (TextView) findViewById(R.id.player4individualThrows19TV);
                guiIndividualThrowFields[3][19] = (TextView) findViewById(R.id.player4individualThrows20TV);
                guiIndividualThrowFields[3][20] = (TextView) findViewById(R.id.player4individualThrows21TV);
                guiIndividualThrowFields[4][0] = (TextView) findViewById(R.id.player5individualThrows1TV);
                guiIndividualThrowFields[4][1] = (TextView) findViewById(R.id.player5individualThrows2TV);
                guiIndividualThrowFields[4][2] = (TextView) findViewById(R.id.player5individualThrows3TV);
                guiIndividualThrowFields[4][3] = (TextView) findViewById(R.id.player5individualThrows4TV);
                guiIndividualThrowFields[4][4] = (TextView) findViewById(R.id.player5individualThrows5TV);
                guiIndividualThrowFields[4][5] = (TextView) findViewById(R.id.player5individualThrows6TV);
                guiIndividualThrowFields[4][6] = (TextView) findViewById(R.id.player5individualThrows7TV);
                guiIndividualThrowFields[4][7] = (TextView) findViewById(R.id.player5individualThrows8TV);
                guiIndividualThrowFields[4][8] = (TextView) findViewById(R.id.player5individualThrows9TV);
                guiIndividualThrowFields[4][9] = (TextView) findViewById(R.id.player5individualThrows10TV);
                guiIndividualThrowFields[4][10] = (TextView) findViewById(R.id.player5individualThrows11TV);
                guiIndividualThrowFields[4][11] = (TextView) findViewById(R.id.player5individualThrows12TV);
                guiIndividualThrowFields[4][12] = (TextView) findViewById(R.id.player5individualThrows13TV);
                guiIndividualThrowFields[4][13] = (TextView) findViewById(R.id.player5individualThrows14TV);
                guiIndividualThrowFields[4][14] = (TextView) findViewById(R.id.player5individualThrows15TV);
                guiIndividualThrowFields[4][15] = (TextView) findViewById(R.id.player5individualThrows16TV);
                guiIndividualThrowFields[4][16] = (TextView) findViewById(R.id.player5individualThrows17TV);
                guiIndividualThrowFields[4][17] = (TextView) findViewById(R.id.player5individualThrows18TV);
                guiIndividualThrowFields[4][18] = (TextView) findViewById(R.id.player5individualThrows19TV);
                guiIndividualThrowFields[4][19] = (TextView) findViewById(R.id.player5individualThrows20TV);
                guiIndividualThrowFields[4][20] = (TextView) findViewById(R.id.player5individualThrows21TV);
                guiIndividualThrowFields[5][0] = (TextView) findViewById(R.id.player6individualThrows1TV);
                guiIndividualThrowFields[5][1] = (TextView) findViewById(R.id.player6individualThrows2TV);
                guiIndividualThrowFields[5][2] = (TextView) findViewById(R.id.player6individualThrows3TV);
                guiIndividualThrowFields[5][3] = (TextView) findViewById(R.id.player6individualThrows4TV);
                guiIndividualThrowFields[5][4] = (TextView) findViewById(R.id.player6individualThrows5TV);
                guiIndividualThrowFields[5][5] = (TextView) findViewById(R.id.player6individualThrows6TV);
                guiIndividualThrowFields[5][6] = (TextView) findViewById(R.id.player6individualThrows7TV);
                guiIndividualThrowFields[5][7] = (TextView) findViewById(R.id.player6individualThrows8TV);
                guiIndividualThrowFields[5][8] = (TextView) findViewById(R.id.player6individualThrows9TV);
                guiIndividualThrowFields[5][9] = (TextView) findViewById(R.id.player6individualThrows10TV);
                guiIndividualThrowFields[5][10] = (TextView) findViewById(R.id.player6individualThrows11TV);
                guiIndividualThrowFields[5][11] = (TextView) findViewById(R.id.player6individualThrows12TV);
                guiIndividualThrowFields[5][12] = (TextView) findViewById(R.id.player6individualThrows13TV);
                guiIndividualThrowFields[5][13] = (TextView) findViewById(R.id.player6individualThrows14TV);
                guiIndividualThrowFields[5][14] = (TextView) findViewById(R.id.player6individualThrows15TV);
                guiIndividualThrowFields[5][15] = (TextView) findViewById(R.id.player6individualThrows16TV);
                guiIndividualThrowFields[5][16] = (TextView) findViewById(R.id.player6individualThrows17TV);
                guiIndividualThrowFields[5][17] = (TextView) findViewById(R.id.player6individualThrows18TV);
                guiIndividualThrowFields[5][18] = (TextView) findViewById(R.id.player6individualThrows19TV);
                guiIndividualThrowFields[5][19] = (TextView) findViewById(R.id.player6individualThrows20TV);
                guiIndividualThrowFields[5][20] = (TextView) findViewById(R.id.player6individualThrows21TV);
                guiFrameScoreFields[0][0] = (TextView) findViewById(R.id.player1frameScores1TV);
                guiFrameScoreFields[0][1] = (TextView) findViewById(R.id.player1frameScores2TV);
                guiFrameScoreFields[0][2] = (TextView) findViewById(R.id.player1frameScores3TV);
                guiFrameScoreFields[0][3] = (TextView) findViewById(R.id.player1frameScores4TV);
                guiFrameScoreFields[0][4] = (TextView) findViewById(R.id.player1frameScores5TV);
                guiFrameScoreFields[0][5] = (TextView) findViewById(R.id.player1frameScores6TV);
                guiFrameScoreFields[0][6] = (TextView) findViewById(R.id.player1frameScores7TV);
                guiFrameScoreFields[0][7] = (TextView) findViewById(R.id.player1frameScores8TV);
                guiFrameScoreFields[0][8] = (TextView) findViewById(R.id.player1frameScores9TV);
                guiFrameScoreFields[0][9] = (TextView) findViewById(R.id.player1frameScores10TV);
                guiFrameScoreFields[1][0] = (TextView) findViewById(R.id.player2frameScores1TV);
                guiFrameScoreFields[1][1] = (TextView) findViewById(R.id.player2frameScores2TV);
                guiFrameScoreFields[1][2] = (TextView) findViewById(R.id.player2frameScores3TV);
                guiFrameScoreFields[1][3] = (TextView) findViewById(R.id.player2frameScores4TV);
                guiFrameScoreFields[1][4] = (TextView) findViewById(R.id.player2frameScores5TV);
                guiFrameScoreFields[1][5] = (TextView) findViewById(R.id.player2frameScores6TV);
                guiFrameScoreFields[1][6] = (TextView) findViewById(R.id.player2frameScores7TV);
                guiFrameScoreFields[1][7] = (TextView) findViewById(R.id.player2frameScores8TV);
                guiFrameScoreFields[1][8] = (TextView) findViewById(R.id.player2frameScores9TV);
                guiFrameScoreFields[1][9] = (TextView) findViewById(R.id.player2frameScores10TV);
                guiFrameScoreFields[2][0] = (TextView) findViewById(R.id.player3frameScores1TV);
                guiFrameScoreFields[2][1] = (TextView) findViewById(R.id.player3frameScores2TV);
                guiFrameScoreFields[2][2] = (TextView) findViewById(R.id.player3frameScores3TV);
                guiFrameScoreFields[2][3] = (TextView) findViewById(R.id.player3frameScores4TV);
                guiFrameScoreFields[2][4] = (TextView) findViewById(R.id.player3frameScores5TV);
                guiFrameScoreFields[2][5] = (TextView) findViewById(R.id.player3frameScores6TV);
                guiFrameScoreFields[2][6] = (TextView) findViewById(R.id.player3frameScores7TV);
                guiFrameScoreFields[2][7] = (TextView) findViewById(R.id.player3frameScores8TV);
                guiFrameScoreFields[2][8] = (TextView) findViewById(R.id.player3frameScores9TV);
                guiFrameScoreFields[2][9] = (TextView) findViewById(R.id.player3frameScores10TV);
                guiFrameScoreFields[3][0] = (TextView) findViewById(R.id.player4frameScores1TV);
                guiFrameScoreFields[3][1] = (TextView) findViewById(R.id.player4frameScores2TV);
                guiFrameScoreFields[3][2] = (TextView) findViewById(R.id.player4frameScores3TV);
                guiFrameScoreFields[3][3] = (TextView) findViewById(R.id.player4frameScores4TV);
                guiFrameScoreFields[3][4] = (TextView) findViewById(R.id.player4frameScores5TV);
                guiFrameScoreFields[3][5] = (TextView) findViewById(R.id.player4frameScores6TV);
                guiFrameScoreFields[3][6] = (TextView) findViewById(R.id.player4frameScores7TV);
                guiFrameScoreFields[3][7] = (TextView) findViewById(R.id.player4frameScores8TV);
                guiFrameScoreFields[3][8] = (TextView) findViewById(R.id.player4frameScores9TV);
                guiFrameScoreFields[3][9] = (TextView) findViewById(R.id.player4frameScores10TV);
                guiFrameScoreFields[4][0] = (TextView) findViewById(R.id.player5frameScores1TV);
                guiFrameScoreFields[4][1] = (TextView) findViewById(R.id.player5frameScores2TV);
                guiFrameScoreFields[4][2] = (TextView) findViewById(R.id.player5frameScores3TV);
                guiFrameScoreFields[4][3] = (TextView) findViewById(R.id.player5frameScores4TV);
                guiFrameScoreFields[4][4] = (TextView) findViewById(R.id.player5frameScores5TV);
                guiFrameScoreFields[4][5] = (TextView) findViewById(R.id.player5frameScores6TV);
                guiFrameScoreFields[4][6] = (TextView) findViewById(R.id.player5frameScores7TV);
                guiFrameScoreFields[4][7] = (TextView) findViewById(R.id.player5frameScores8TV);
                guiFrameScoreFields[4][8] = (TextView) findViewById(R.id.player5frameScores9TV);
                guiFrameScoreFields[4][9] = (TextView) findViewById(R.id.player5frameScores10TV);
                guiFrameScoreFields[5][0] = (TextView) findViewById(R.id.player6frameScores1TV);
                guiFrameScoreFields[5][1] = (TextView) findViewById(R.id.player6frameScores2TV);
                guiFrameScoreFields[5][2] = (TextView) findViewById(R.id.player6frameScores3TV);
                guiFrameScoreFields[5][3] = (TextView) findViewById(R.id.player6frameScores4TV);
                guiFrameScoreFields[5][4] = (TextView) findViewById(R.id.player6frameScores5TV);
                guiFrameScoreFields[5][5] = (TextView) findViewById(R.id.player6frameScores6TV);
                guiFrameScoreFields[5][6] = (TextView) findViewById(R.id.player6frameScores7TV);
                guiFrameScoreFields[5][7] = (TextView) findViewById(R.id.player6frameScores8TV);
                guiFrameScoreFields[5][8] = (TextView) findViewById(R.id.player6frameScores9TV);
                guiFrameScoreFields[5][9] = (TextView) findViewById(R.id.player6frameScores10TV);
                scoreFields[0] = (TextView) findViewById(R.id.player1cumulativeScoreTV);
                scoreFields[1] = (TextView) findViewById(R.id.player2cumulativeScoreTV);
                scoreFields[2] = (TextView) findViewById(R.id.player3cumulativeScoreTV);
                scoreFields[3] = (TextView) findViewById(R.id.player4cumulativeScoreTV);
                scoreFields[4] = (TextView) findViewById(R.id.player5cumulativeScoreTV);
                scoreFields[5] = (TextView) findViewById(R.id.player6cumulativeScoreTV);
                break;
        }
    }

    private void reFormatXMLFile() {
        layout1 = (LinearLayout) findViewById(R.id.scorePanel1);
        layout2 = (LinearLayout) findViewById(R.id.scorePanel2);
        layout3 = (LinearLayout) findViewById(R.id.scorePanel3);
        layout4 = (LinearLayout) findViewById(R.id.scorePanel4);
        layout5 = (LinearLayout) findViewById(R.id.scorePanel5);
        layout6 = (LinearLayout) findViewById(R.id.scorePanel6);
        switch (numberOfPlayersString){
            case "1":
                player1NameTV = (TextView) findViewById(R.id.player1TV);
                player1NameTV.setText(scoreboard.players[0].name);
                layout2.removeAllViewsInLayout();
                layout3.removeAllViewsInLayout();
                layout4.removeAllViewsInLayout();
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "2":
                player1NameTV = (TextView) findViewById(R.id.player1TV);
                player1NameTV.setText(scoreboard.players[0].name);
                player2NameTV = (TextView) findViewById(R.id.player2TV);
                player2NameTV.setText(scoreboard.players[1].name);
                layout3.removeAllViewsInLayout();
                layout4.removeAllViewsInLayout();
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "3":
                player1NameTV = (TextView) findViewById(R.id.player1TV);
                player1NameTV.setText(scoreboard.players[0].name);
                player2NameTV = (TextView) findViewById(R.id.player2TV);
                player2NameTV.setText(scoreboard.players[1].name);
                player3NameTV = (TextView) findViewById(R.id.player3TV);
                player3NameTV.setText(scoreboard.players[2].name);
                layout4.removeAllViewsInLayout();
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "4":
                player1NameTV = (TextView) findViewById(R.id.player1TV);
                player1NameTV.setText(scoreboard.players[0].name);
                player2NameTV = (TextView) findViewById(R.id.player2TV);
                player2NameTV.setText(scoreboard.players[1].name);
                player3NameTV = (TextView) findViewById(R.id.player3TV);
                player3NameTV.setText(scoreboard.players[2].name);
                player4NameTV = (TextView) findViewById(R.id.player4TV);
                player4NameTV.setText(scoreboard.players[3].name);
                layout5.removeAllViewsInLayout();
                layout6.removeAllViewsInLayout();
                break;
            case "5":
                player1NameTV = (TextView) findViewById(R.id.player1TV);
                player1NameTV.setText(scoreboard.players[0].name);
                player2NameTV = (TextView) findViewById(R.id.player2TV);
                player1NameTV.setText(scoreboard.players[1].name);
                player3NameTV = (TextView) findViewById(R.id.player3TV);
                player3NameTV.setText(scoreboard.players[2].name);
                player4NameTV = (TextView) findViewById(R.id.player4TV);
                player4NameTV.setText(scoreboard.players[3].name);
                player5NameTV = (TextView) findViewById(R.id.player5TV);
                player5NameTV.setText(scoreboard.players[4].name);
                layout6.removeAllViewsInLayout();
                break;
            case "6":
                player1NameTV = (TextView) findViewById(R.id.player1TV);
                player1NameTV.setText(scoreboard.players[0].name);
                player2NameTV = (TextView) findViewById(R.id.player2TV);
                player2NameTV.setText(scoreboard.players[1].name);
                player3NameTV = (TextView) findViewById(R.id.player3TV);
                player3NameTV.setText(scoreboard.players[2].name);
                player4NameTV = (TextView) findViewById(R.id.player4TV);
                player4NameTV.setText(scoreboard.players[3].name);
                player5NameTV = (TextView) findViewById(R.id.player5TV);
                player5NameTV.setText(scoreboard.players[4].name);
                player6NameTV = (TextView) findViewById(R.id.player6TV);
                player6NameTV.setText(scoreboard.players[5].name);
                break;

        }

    }

    private void getExtras() {
        extras = getIntent().getExtras();
        username = extras.getString("Username");
        gameType = extras.getString("Game Type");
        // TODO get the layout array to parse to the scoreboard constructor
        switch (gameType) {
            case "New Game":
                numberOfPlayersString = extras.getString("Number Of Players");
                numberOfPlayers = Integer.parseInt(numberOfPlayersString);
                players = new Player[numberOfPlayers];
                currentPlayerIndex = 0;
                throwFieldsIndex = 0;
                switch (numberOfPlayersString) {
                    case "1":
                        players[0] = new Player(extras.getString("Player 1 Name"));
                        break;
                    case "2":
                        players[0] = new Player(extras.getString("Player 1 Name"));
                        players[1] = new Player(extras.getString("Player 2 Name"));
                        break;
                    case "3":
                        players[0] = new Player(extras.getString("Player 1 Name"));
                        players[1] = new Player(extras.getString("Player 2 Name"));
                        players[2] = new Player(extras.getString("Player 3 Name"));
                        break;
                    case "4":
                        players[0] = new Player(extras.getString("Player 1 Name"));
                        players[1] = new Player(extras.getString("Player 2 Name"));
                        players[2] = new Player(extras.getString("Player 3 Name"));
                        players[3] = new Player(extras.getString("Player 4 Name"));
                        break;
                    case "5":
                        players[0] = new Player(extras.getString("Player 1 Name"));
                        players[1] = new Player(extras.getString("Player 2 Name"));
                        players[2] = new Player(extras.getString("Player 3 Name"));
                        players[3] = new Player(extras.getString("Player 4 Name"));
                        players[4] = new Player(extras.getString("Player 5 Name"));
                        break;
                    case "6":
                        players[0] = new Player(extras.getString("Player 1 Name"));
                        players[1] = new Player(extras.getString("Player 2 Name"));
                        players[2] = new Player(extras.getString("Player 3 Name"));
                        players[3] = new Player(extras.getString("Player 4 Name"));
                        players[4] = new Player(extras.getString("Player 5 Name"));
                        players[5] = new Player(extras.getString("Player 6 Name"));
                        break;
                }
                scoreboard = new Scoreboard(players);
                setUpGUIScoreboard();
                throwOfFrame = 1;
                currentFrame = 1;
                break;
            case "Loaded Game":
                gameData = extras.getString("Game Data");
                String[] gameDataValues = gameData.split(",");
                currentFrame = Integer.parseInt(gameDataValues[0]);
                throwOfFrame = Integer.parseInt(gameDataValues[1]);
                currentPlayerIndex = Integer.parseInt(gameDataValues[2]);
                throwFieldsIndex = 2*(currentFrame - 1) + (throwOfFrame - 1);
                String[] individualPlayersData = gameDataValues[3].split(";");
                numberOfPlayers = individualPlayersData.length;
                numberOfPlayersString = Integer.toString(numberOfPlayers);
                players = new Player[numberOfPlayers];
                for (int index = 0; index < numberOfPlayers; index++) {
                    String[] playerData = individualPlayersData[index].split(":");
                    players[index] = new Player(playerData[0]);
                    players[index].score = new Score(playerData[1]);
                }
                scoreboard = new Scoreboard(players);
                if (throwOfFrame != 1) {
                    makeInvalidNumberedButtonsInvisible(Integer.toString(scoreboard.getLastThrowValue(currentPlayerIndex)));
                }
                setUpGUIScoreboard();
                fillDataOnGUI();
                break;
        }
        reFormatXMLFile();
    }

    private void fillDataOnGUI() {
        for (int playerIndex = 0; playerIndex < numberOfPlayers; playerIndex++){
            int throwIndex = 0;
            while (!scoreboard.players[playerIndex].score.scoreBoxFormats[throwIndex].equals("null")){
                guiIndividualThrowFields[playerIndex][throwIndex].setText(scoreboard.players[playerIndex].score.scoreBoxFormats[throwIndex]);
                throwIndex++;
            }
            int frameIndex = 0;
            while (!scoreboard.players[playerIndex].score.scoreBoxFormats[frameIndex + 21].equals("null")){
                guiFrameScoreFields[playerIndex][frameIndex].setText(scoreboard.players[playerIndex].score.scoreBoxFormats[frameIndex + 21]);
                frameIndex++;
            }
            if (!scoreboard.players[playerIndex].score.scoreBoxFormats[31].equals("null")){
                scoreFields[playerIndex].setText(scoreboard.players[playerIndex].score.scoreBoxFormats[31]);
            }
        }
    }

    private void setUpButtons() {

        button0 = (Button) findViewById(R.id.button0);
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(0);
                onButtonsClicked(0);
            }
        });

        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(1);
                onButtonsClicked(1);

            }
        });

        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(2);
                onButtonsClicked(2);
            }
        });

        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(3);
                onButtonsClicked(3);

            }
        });

        button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(4);
                onButtonsClicked(4);

            }
        });

        button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(5);
                onButtonsClicked(5);
            }
        });

        button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(6);
                onButtonsClicked(6);

            }
        });

        button7 = (Button) findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(7);
                onButtonsClicked(7);

            }
        });

        button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(8);
                onButtonsClicked(8);

            }
        });

        button9 = (Button) findViewById(R.id.button9);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(9);
                onButtonsClicked(9);
            }
        });

        button10 = (Button) findViewById(R.id.button10);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreboard.players[currentPlayerIndex].score.update(10);
                onButtonsClicked(10);
            }
        });

        quitButton = (Button) findViewById(R.id.quitButton);
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                intent.putExtra("Username", username);
                startActivity(intent);

            }
        });

        saveButton = (Button) findViewById(R.id.saveButton);
    }

    private void makeAllNumberedButtonsVisible(){
        button0.setVisibility(View.VISIBLE);
        button1.setVisibility(View.VISIBLE);
        button2.setVisibility(View.VISIBLE);
        button3.setVisibility(View.VISIBLE);
        button4.setVisibility(View.VISIBLE);
        button5.setVisibility(View.VISIBLE);
        button6.setVisibility(View.VISIBLE);
        button7.setVisibility(View.VISIBLE);
        button8.setVisibility(View.VISIBLE);
        button9.setVisibility(View.VISIBLE);
        button10.setVisibility(View.VISIBLE);
    }

    public void  updatePlayerIndex(){
        if (currentPlayerIndex == numberOfPlayers - 1){
            currentPlayerIndex = 0;
            currentFrame++;
        } else {
            currentPlayerIndex++;
            if (throwOfFrame == 3){
                throwFieldsIndex -= 3;
            } else {
                throwFieldsIndex -= 2;
            }
        }
        throwOfFrame = 1;
        makeAllNumberedButtonsVisible();
    }

    private void updateGameState(int pinsKnockedDown) {
        if (currentFrame != 10) {
            // Frames 1-9: no special conditions apply
            if (throwOfFrame == 1) {
                if (pinsKnockedDown != 10) {
                    throwOfFrame = 2;
                } else {
                    updatePlayerIndex();
                }
            } else {
                updatePlayerIndex();
            }
        } else {
            // Frame 10: special conditions apply
            if (throwOfFrame == 1){
                throwOfFrame = 2;
            } else if (throwOfFrame == 2){
                if (scoreboard.players[currentPlayerIndex].score.individualThrows[18] + pinsKnockedDown <= 10){
                    updatePlayerIndex();
                } else {
                    throwOfFrame = 3;
                }
            } else {
                updatePlayerIndex();
            }
        }
    }

    private void onButtonsClicked(int buttonNumber){
        makeInvalidNumberedButtonsInvisible(Integer.toString(buttonNumber));
        // Display the individual throw
        guiIndividualThrowFields[currentPlayerIndex][throwFieldsIndex].setText(scoreboard.players[currentPlayerIndex].score.scoreBoxFormats[throwFieldsIndex]);
        throwFieldsIndex++;
        if (buttonNumber == 10){
            //There may have been a strike
            if (throwFieldsIndex < 18){
                // The throw was made within frames 1-9 and no special conditions apply
                if (scoreboard.players[currentPlayerIndex].score.scoreBoxFormats[throwFieldsIndex-1].equals("   ")){
                    guiIndividualThrowFields[currentPlayerIndex][throwFieldsIndex].setText(scoreboard.players[currentPlayerIndex].score.scoreBoxFormats[throwFieldsIndex]);
                    throwFieldsIndex++;
                }
            }
        }

        // Display the cumulative frame score
        int index = 0;
        while (!scoreboard.players[currentPlayerIndex].score.scoreBoxFormats[index + 21].equals("null")){
            guiFrameScoreFields[currentPlayerIndex][index].setText(scoreboard.players[currentPlayerIndex].score.scoreBoxFormats[index + 21]);
            index++;
        }
        scoreFields[currentPlayerIndex].setText(scoreboard.players[currentPlayerIndex].score.scoreBoxFormats[31]);
        updateGameState(buttonNumber);
        checkGameIsComplete();
    }

    private void makeInvalidNumberedButtonsInvisible(String buttonNumber){
        switch (buttonNumber){
            case "0":
                makeAllNumberedButtonsVisible();;
                break;
            case "1":
                button10.setVisibility(View.INVISIBLE);
                break;
            case "2":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                break;
            case "3":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                break;
            case "4":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                button7.setVisibility(View.INVISIBLE);
                break;
            case "5":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                button7.setVisibility(View.INVISIBLE);
                button6.setVisibility(View.INVISIBLE);
                break;
            case "6":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                button7.setVisibility(View.INVISIBLE);
                button6.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                break;
            case "7":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                button7.setVisibility(View.INVISIBLE);
                button6.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                break;
            case "8":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                button7.setVisibility(View.INVISIBLE);
                button6.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                break;
            case "9":
                button10.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                button7.setVisibility(View.INVISIBLE);
                button6.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button2.setVisibility(View.INVISIBLE);
                break;
            case "10":
                makeAllNumberedButtonsVisible();
                break;
        }
    }

    public void OnSaveGame (View view){
        gameData = "";
        gameData += Integer.toString(currentFrame) + "," + Integer.toString(throwOfFrame) + "," + Integer.toString(currentPlayerIndex) + ",";
        gameData += scoreboard.toString();
        saveGameDAO = new SaveGameDAO(this);
        saveGameDAO.execute(activity, username, gameData);

    }

    private void checkGameIsComplete(){
        if (scoreboard.players[numberOfPlayers-1].score.isFinalised){
            saveButton.setVisibility(View.INVISIBLE);
            button0.setVisibility(View.INVISIBLE);
            button1.setVisibility(View.INVISIBLE);
            button2.setVisibility(View.INVISIBLE);
            button3.setVisibility(View.INVISIBLE);
            button4.setVisibility(View.INVISIBLE);
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            button7.setVisibility(View.INVISIBLE);
            button8.setVisibility(View.INVISIBLE);
            button9.setVisibility(View.INVISIBLE);
            button10.setVisibility(View.INVISIBLE);
        }
    }

}

