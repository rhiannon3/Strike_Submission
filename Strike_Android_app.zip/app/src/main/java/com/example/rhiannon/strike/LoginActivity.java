package com.example.rhiannon.strike;

        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    EditText usernameField, passwordField;
    String username, password;
    LoginDAO loginDAO;
    static String activity = "login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        usernameField = (EditText) findViewById(R.id.userNameInputField);
        passwordField = (EditText) findViewById(R.id.passwordInputField);

    }

    public void onLogin (View view) {
        username = usernameField.getText().toString();
        password = passwordField.getText().toString();
        loginDAO = new LoginDAO(this);
        loginDAO.execute(activity, username, password);

    }
}
